# Servidor mock que simula el lado SAP: recibe escaneos de anaquel y expone un
# resumen de cumplimiento de planograma. Corre en cualquier máquina con Python 3:
#   python3 sap/mock_server.py            # http://127.0.0.1:8787
# Endpoints: POST /api/scan · GET /api/scans · GET /api/compliance

import json
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer

SCANS: list[dict] = []


def compliance() -> dict:
    lines = [line for scan in SCANS for line in scan["Lines"]]
    total = len(lines)
    ok = sum(1 for line in lines if line["Status"] == "OK")
    oos = [f"{line['Gondola']}/{line['Product']}" for line in lines if line["Status"] == "OUT_OF_STOCK"]
    low = [f"{line['Gondola']}/{line['Product']}" for line in lines if line["Status"] == "LOW"]
    return {"scans": len(SCANS), "lines": total, "compliance_pct": round(100 * ok / total, 1) if total else None, "out_of_stock": oos, "low": low}


class Handler(BaseHTTPRequestHandler):
    def _json(self, code: int, payload: dict) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self) -> None:  # noqa: N802
        if self.path != "/api/scan":
            return self._json(404, {"error": "not found"})
        length = int(self.headers.get("Content-Length", "0"))
        doc = json.loads(self.rfile.read(length) or b"{}")
        SCANS.append(doc)
        print(f"[mock-sap] scan {doc.get('ScanId')} · {len(doc.get('Lines', []))} líneas · cumplimiento {compliance()['compliance_pct']}%")
        self._json(201, {"accepted": doc.get("ScanId"), "compliance": compliance()})

    def do_GET(self) -> None:  # noqa: N802
        if self.path == "/api/scans":
            return self._json(200, {"scans": SCANS})
        if self.path == "/api/compliance":
            return self._json(200, compliance())
        self._json(404, {"error": "not found"})

    def log_message(self, *_args) -> None:
        return


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8787
    print(f"[mock-sap] escuchando en http://127.0.0.1:{port}")
    HTTPServer(("127.0.0.1", port), Handler).serve_forever()
