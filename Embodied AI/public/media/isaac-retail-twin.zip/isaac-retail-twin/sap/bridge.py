# Puente Isaac -> SAP. Convierte la evidencia de un escaneo en un documento de
# "inventario de anaquel" y lo envía por HTTP. Hoy apunta al mock_server.py;
# para S/4HANA Retail se cambia la URL y el mapeo en to_sap_document().

from __future__ import annotations

import json
import urllib.request


def to_sap_document(evidence: dict) -> dict:
    """Documento neutral: por góndola, SKUs con facings esperados, vacíos y detectados."""
    lines = []
    for scan in evidence.get("scans", []):
        for sku, expected in scan["expected_facings"].items():
            lines.append({
                "Site": evidence.get("site"),
                "Gondola": scan["gondola"],
                "Product": sku,
                "ExpectedFacings": expected,
                "EmptyFacings": scan["empty_facings_truth"].get(sku, 0),
                "DetectedFacings": scan["skus_detected"].get(sku, 0),
                "Status": "OUT_OF_STOCK" if scan["empty_facings_truth"].get(sku, 0) >= expected else ("LOW" if scan["empty_facings_truth"].get(sku, 0) > 0 else "OK"),
            })
    return {"ScanId": f"{evidence.get('mission')}-{int(evidence.get('started', 0))}", "Robot": evidence.get("robot"), "Site": evidence.get("site"), "Lines": lines}


def post_scan(url: str, evidence: dict, timeout: float = 10.0) -> dict:
    body = json.dumps(to_sap_document(evidence)).encode("utf-8")
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as res:
        return json.loads(res.read().decode("utf-8"))


if __name__ == "__main__":
    import sys
    from pathlib import Path

    path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("evidence/scan-A1-A5/evidence.json")
    url = sys.argv[2] if len(sys.argv) > 2 else "http://127.0.0.1:8787/api/scan"
    print(json.dumps(post_scan(url, json.loads(path.read_text(encoding="utf-8"))), indent=2))
