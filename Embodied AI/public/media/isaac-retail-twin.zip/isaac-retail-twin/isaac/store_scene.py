# Retail Store Twin · construcción de la escena a partir de scenario/store.json
#
# Librería usada por build_store.py y scan_mission.py. No crea la SimulationApp:
# el script que la importa debe haberla creado antes. Pensado para Isaac Sim 5.1;
# los puntos que cambian en 6.x están marcados con "6.x".

from __future__ import annotations

import json
import math
import random
from pathlib import Path

import numpy as np

from isaacsim.core.api import World
from isaacsim.core.api.objects import FixedCuboid, GroundPlane, VisualCuboid
from isaacsim.core.utils.prims import create_prim, get_prim_at_path, is_prim_path_valid
from isaacsim.core.utils.stage import add_reference_to_stage
from isaacsim.storage.native import get_assets_root_path, is_file

try:  # 5.x
    from isaacsim.core.utils.semantics import add_labels as _add_labels

    def label(prim_path: str, cls: str) -> None:
        _add_labels(get_prim_at_path(prim_path), labels=[cls], instance_name="class")

except ImportError:  # 4.5 / 6.x fallback
    from isaacsim.core.utils.semantics import add_update_semantics

    def label(prim_path: str, cls: str) -> None:
        add_update_semantics(get_prim_at_path(prim_path), semantic_label=cls)


ROOT = Path(__file__).resolve().parents[1]
_n = lambda prim_path: prim_path.strip("/").replace("/", "_")  # nombre único por objeto (Isaac lo exige)
SCENARIO = ROOT / "scenario" / "store.json"

FLOOR = np.array([0.82, 0.82, 0.80])
WALL = np.array([0.92, 0.92, 0.90])
STEEL = np.array([0.55, 0.57, 0.60])
PRODUCT_COLORS = {
    "CEREAL": [0.90, 0.55, 0.15], "GALLETA": [0.75, 0.45, 0.20], "AVENA": [0.85, 0.75, 0.45],
    "LECHE": [0.95, 0.95, 0.95], "YOGURT": [0.85, 0.65, 0.80], "JUGO": [0.95, 0.60, 0.20], "AGUA": [0.55, 0.75, 0.95],
    "ARROZ": [0.95, 0.92, 0.80], "FRIJOL": [0.35, 0.20, 0.15], "ACEITE": [0.90, 0.85, 0.30], "ATUN": [0.30, 0.55, 0.85],
    "DETERG": [0.20, 0.45, 0.85], "JABON": [0.60, 0.85, 0.60], "PAPEL": [0.98, 0.98, 0.98], "SHAMPOO": [0.65, 0.35, 0.75],
    "PAN": [0.85, 0.65, 0.35], "TORTILLA": [0.95, 0.90, 0.70], "CAFE": [0.30, 0.20, 0.12], "AZUCAR": [0.90, 0.90, 0.90],
}


def load_scenario(path: Path = SCENARIO) -> dict:
    """Carga el escenario y aplica origin_offset para que todo quede en coordenadas de mundo."""
    sc = json.loads(Path(path).read_text(encoding="utf-8"))
    ox, oy, oz = sc.get("origin_offset", [0.0, 0.0, 0.0])
    if ox or oy or oz:
        for g in sc["gondolas"]:
            g["x"], g["y"] = g["x"] + ox, g["y"] + oy
        for r in sc["robots"]:
            r["dock"] = [r["dock"][0] + ox, r["dock"][1] + oy, r["dock"][2] + oz]
        for m in sc["missions"].values():
            for w in m["waypoints"]:
                w["x"], w["y"] = w["x"] + ox, w["y"] + oy
    return sc


def _color(sku: str) -> np.ndarray:
    return np.array(PRODUCT_COLORS.get(sku.split("-")[0], [0.6, 0.6, 0.6]))


def build_shell(world: World, sc: dict) -> None:
    """Piso, paredes y luz de la tienda."""
    w, d, h = sc["store"]["width"], sc["store"]["depth"], sc["store"]["wall_height"]
    world.scene.add(GroundPlane(prim_path="/World/Floor", name=_n("/World/Floor"), size=max(w, d) * 2, color=FLOOR))
    t = 0.2
    walls = {
        "South": ([w / 2, -t / 2, h / 2], [w, t, h]),
        "North": ([w / 2, d + t / 2, h / 2], [w, t, h]),
        "West": ([-t / 2, d / 2, h / 2], [t, d, h]),
        "East": ([w + t / 2, d / 2, h / 2], [t, d, h]),
        "Backroom": ([24.0, 7.0, h / 2], [t, 14.0, h]),
    }
    for name, (pos, scale) in walls.items():
        world.scene.add(FixedCuboid(prim_path=f"/World/Walls/{name}", name=_n(f"/World/Walls/{name}"), position=np.array(pos), scale=np.array(scale), color=WALL))
    create_prim("/World/Light", "DistantLight", attributes={"inputs:intensity": 3000.0, "inputs:angle": 1.0})
    create_prim("/World/Dome", "DomeLight", attributes={"inputs:intensity": 900.0})


def build_gondola(world: World, g: dict, rng: random.Random, oos_ratio: float, ground_truth: dict) -> None:
    """Góndola de dos caras con niveles y facings; algunos facings quedan vacíos (out of stock)."""
    gid, x0, y0, length, height = g["id"], g["x"], g["y"], g["length"], g["height"]
    levels, facings = g["levels"], g["facings_per_level"]
    depth = 0.9
    base = f"/World/Gondolas/{gid}"
    world.scene.add(FixedCuboid(prim_path=f"{base}/Frame", name=_n(f"{base}/Frame"), position=np.array([x0, y0 + length / 2, height / 2]), scale=np.array([0.12, length, height]), color=STEEL))
    level_h = height / levels
    slot_len = length / facings
    ground_truth[gid] = {}
    for side, sx in (("L", -1), ("R", 1)):
        for lv in range(levels):
            z_board = (lv + 1) * level_h - 0.02
            world.scene.add(FixedCuboid(prim_path=f"{base}/Board_{side}{lv}", name=_n(f"{base}/Board_{side}{lv}"), position=np.array([x0 + sx * depth / 4, y0 + length / 2, z_board]), scale=np.array([depth / 2, length, 0.03]), color=STEEL))
            sku = g["products"][lv % len(g["products"])]
            for f in range(facings):
                key = f"{side}{lv}-{f:02d}"
                in_stock = rng.random() >= oos_ratio
                ground_truth[gid][key] = {"sku": sku, "in_stock": in_stock}
                if not in_stock:
                    continue
                size = np.array([0.22, slot_len * 0.8, level_h * 0.6])
                pos = np.array([x0 + sx * (depth / 4), y0 + (f + 0.5) * slot_len, z_board + size[2] / 2 + 0.02])
                path = f"{base}/P_{side}{lv}_{f:02d}"
                world.scene.add(VisualCuboid(prim_path=path, name=_n(path), position=pos, scale=size, color=_color(sku)))
                label(path, f"product_{sku}")
    label(f"{base}/Frame", "shelf")


def spawn_amr(world: World, robot: dict):
    """Coloca el AMR escáner. Devuelve (prim_path, WheeledRobot|None)."""
    assets = get_assets_root_path()
    usd = next((c for c in robot["asset_candidates"] if is_file(assets + c)), None)
    path = f"/World/Robots/{robot['id'].replace('-', '_')}"
    if usd is None:
        print(f"[store_scene] No encontré el USD del AMR; uso un cubo como marcador en {path}")
        world.scene.add(VisualCuboid(prim_path=path, name=_n(path), position=np.array(robot["dock"]) + np.array([0, 0, 0.3]), scale=np.array([0.7, 0.5, 0.6]), color=np.array([0.1, 0.3, 0.8])))
        return path, None
    add_reference_to_stage(assets + usd, path)
    try:
        from isaacsim.robot.wheeled_robots.robots import WheeledRobot  # 5.x
    except ImportError:  # 6.x mueve el wrapper; se controla por articulación directa
        WheeledRobot = None
    if WheeledRobot is None:
        return path, None
    wr = world.scene.add(WheeledRobot(prim_path=path, name=robot["id"], wheel_dof_names=robot["wheel_joints"], create_robot=False, position=np.array(robot["dock"])))
    return path, wr


def attach_shelf_camera(robot_path: str, robot: dict, resolution=(1280, 720)):
    """Cámara lateral que mira a la góndola (yaw 90°) para capturar facings."""
    from isaacsim.sensors.camera import Camera
    from scipy.spatial.transform import Rotation as R

    parent = f"{robot_path}/{robot['camera_parent']}"
    if not is_prim_path_valid(parent):
        parent = robot_path
    q = R.from_euler("z", robot["camera_yaw_deg"], degrees=True).as_quat()  # x y z w
    cam = Camera(prim_path=f"{parent}/shelf_cam", translation=np.array(robot["camera_offset"]), orientation=np.array([q[3], q[0], q[1], q[2]]), resolution=resolution, frequency=10)
    cam.set_focal_length(1.6)
    return cam


def build_store(world: World, sc: dict) -> dict:
    """Construye toda la tienda y devuelve el ground truth de facings por góndola."""
    rng = random.Random(sc.get("out_of_stock_seed", 0))
    ground_truth: dict = {}
    env = sc.get("environment_usd")
    if env:  # escenario de almacén: usa un entorno de Isaac en vez de construir paredes
        add_reference_to_stage(get_assets_root_path() + env, "/World/Env")
        print(f"[store_scene] entorno Isaac: {env}")
    else:
        build_shell(world, sc)
    for g in sc["gondolas"]:
        build_gondola(world, g, rng, sc.get("out_of_stock_ratio", 0.0), ground_truth)
    total = sum(len(v) for v in ground_truth.values())
    oos = sum(1 for v in ground_truth.values() for f in v.values() if not f["in_stock"])
    print(f"[store_scene] {len(sc['gondolas'])} góndolas · {total} facings · {oos} vacíos ({100 * oos / max(total, 1):.1f}%)")
    return ground_truth


def heading_to(from_xy, to_xy) -> float:
    return math.atan2(to_xy[1] - from_xy[1], to_xy[0] - from_xy[0])
