# Ejecutor de misiones del twin SAP para NVIDIA Isaac Sim.
#
# Pregunta al twin si hay una misión (rutina en modo "Isaac"), la reclama, lleva
# al robot nodo por nodo y reporta cada movimiento, paso, sensor y foto. El twin
# traduce esos reportes a su animación, así el robot en pantalla se mueve cuando
# el de Isaac se mueve.
#
#   Modo prueba (sin GPU, cualquier máquina con Python 3):
#     python3 isaac/twin_executor.py --twin https://sap-embodied-twin.cfapps.eu20-002.hana.ondemand.com --token-file ~/.twin-isaac-token --dry-run
#
#   Modo Isaac Sim (en la instancia con GPU):
#     ./python.sh isaac/twin_executor.py --twin <url> --token-file <archivo> --scenario scenario/warehouse.json
#     (en Brev usa --livestream y abre la pestaña /viewer; --headless si no quieres ver nada;
#      el driver físico vive en isaac_driver.py)
#
# El token nunca se pasa por línea de comandos en claro: va en un archivo o en
# la variable de entorno TWIN_ISAAC_TOKEN.

from __future__ import annotations

import argparse
import base64
import io
import json
import math
import os
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--twin", required=True, help="URL base del twin, p. ej. https://sap-embodied-twin.cfapps.eu20-002.hana.ondemand.com")
parser.add_argument("--token-file", default=None, help="Archivo con el token compartido (o usa TWIN_ISAAC_TOKEN)")
parser.add_argument("--dry-run", action="store_true", help="Sin Isaac Sim: simula tiempos por distancia y manda fotos generadas")
parser.add_argument("--scenario", default=None, help="scenario JSON con la escena (solo modo Isaac)")
parser.add_argument("--speed", type=float, default=0.8, help="velocidad del robot en m/s")
parser.add_argument("--poll", type=float, default=1.0, help="segundos entre consultas al twin")
parser.add_argument("--once", action="store_true", help="ejecuta una sola misión y termina")
parser.add_argument("--name", default=None)
parser.add_argument("--headless", action="store_true", help="Isaac Sim sin ventana")
parser.add_argument("--livestream", action="store_true", help="Isaac Sim sin ventana pero transmitido al visor web (Brev: pestaña /viewer)")
args, _ = parser.parse_known_args()

TOKEN = os.environ.get("TWIN_ISAAC_TOKEN") or (Path(args.token_file).expanduser().read_text(encoding="utf-8").strip() if args.token_file else "")
if not TOKEN:
    raise SystemExit("Falta el token: usa --token-file o TWIN_ISAAC_TOKEN")
EXECUTOR = {"id": f"isaac-{os.uname().nodename[:24]}", "name": args.name or ("Isaac executor" if args.dry_run else "Isaac Sim"), "scene": args.scenario or ("none" if args.dry_run else "warehouse"), "version": "0.1", "dryRun": args.dry_run}


def call(path: str, body: dict, timeout: float = 15.0) -> dict:
    req = urllib.request.Request(f"{args.twin.rstrip('/')}{path}", data=json.dumps(body).encode("utf-8"), method="POST", headers={"Content-Type": "application/json", "x-isaac-token": TOKEN})
    with urllib.request.urlopen(req, timeout=timeout) as res:
        return json.loads(res.read().decode("utf-8") or "{}")


class MissionClosed(Exception):
    pass


def report(job_id: str, events: list[dict]) -> None:
    try:
        call("/api/isaac/executor/events", {"jobId": job_id, "events": events})
    except urllib.error.HTTPError as error:
        if error.code in (404, 409):
            raise MissionClosed(error.read().decode("utf-8", "ignore")[:200]) from error
        raise


def snapshot_jpeg(label: str, step_index: int, total: int, progress: float | None = None, moving: str | None = None) -> str | None:
    """Foto de la cámara del robot. En dry run genera una tarjeta con el paso o el trayecto."""
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return None
    img = Image.new("RGB", (640, 360), (11, 18, 32))
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, 640, 34], fill=(118, 185, 0))
    d.text((12, 10), f"ISAAC EXECUTOR · {'DRY RUN' if args.dry_run else 'PHYSICS'}", fill=(11, 18, 32))
    d.text((12, 60), f"step {step_index + 1}/{total}", fill=(200, 210, 220))
    d.text((12, 84), label[:60], fill=(255, 255, 255))
    if moving:
        d.text((12, 130), f"AMR moving · {moving[:50]}", fill=(160, 200, 255))
    if progress is not None:
        d.rectangle([12, 170, 628, 190], outline=(90, 110, 130))
        d.rectangle([12, 170, 12 + int(616 * max(0.0, min(1.0, progress))), 190], fill=(118, 185, 0))
        cx = 12 + int(616 * max(0.0, min(1.0, progress)))
        d.ellipse([cx - 14, 150, cx + 14, 178], fill=(30, 120, 220), outline=(255, 255, 255))
    d.text((12, 330), time.strftime("%H:%M:%S"), fill=(120, 130, 140))
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=70)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode("ascii")


class DryRunDriver:
    """Sin física: estima el tiempo de viaje por distancia y velocidad."""

    def __init__(self):
        self.nodes, self.pos = {}, None

    def reset(self, nodes: dict) -> None:
        self.nodes, self.pos = nodes, None

    def travel(self, from_id: str, to_id: str, on_frame=None) -> float:
        a, b = self.nodes[from_id]["meters"], self.nodes[to_id]["meters"]
        eta = max(0.8, math.hypot(b[0] - a[0], b[1] - a[1]) / args.speed)
        t0, label = time.time(), f"{self.nodes[from_id]['name']} → {self.nodes[to_id]['name']}"
        while time.time() - t0 < eta:
            if on_frame:
                on_frame(snapshot_jpeg(label, 0, 1, progress=(time.time() - t0) / eta, moving=label), label)
            time.sleep(min(1.0, max(0.05, eta - (time.time() - t0))))
        self.pos = to_id
        return eta

    def act(self, step: dict) -> float:
        dwell = max(0.6, float(step.get("duration", 1)) * 1.2)
        time.sleep(dwell)
        return dwell

    def camera_snapshot(self, caption: str, step_index: int = 0, total: int = 1) -> str | None:
        return snapshot_jpeg(caption, step_index, total)

    def idle(self, seconds: float) -> None:
        time.sleep(seconds)

    def close(self) -> None:
        return None


def run_mission(mission: dict, driver) -> None:
    job = mission["jobId"]
    nodes = {n["id"]: n for n in mission["nodes"]}
    driver.reset(nodes)
    steps, total = mission["steps"], len(mission["steps"])
    started = time.time()
    report(job, [{"type": "log", "message": f"Executing {mission['scenarioName']} · {total} steps × {mission['cycles']} cycles"}])
    previous = steps[0]["nodeId"]
    driver.pos = previous
    for cycle in range(1, int(mission["cycles"]) + 1):
        for i, step in enumerate(steps):
            target = step["nodeId"]
            if target != previous:
                a, b = nodes[previous]["meters"], nodes[target]["meters"]
                eta = max(0.8, math.hypot(b[0] - a[0], b[1] - a[1]) / args.speed)
                report(job, [{"type": "transfer", "fromNodeId": previous, "toNodeId": target, "etaMs": int(eta * 1000), "label": f"{nodes[previous]['name']} → {nodes[target]['name']}"}])
                driver.travel(previous, target, on_frame=lambda image, caption: image and report(job, [{"type": "snapshot", "nodeId": target, "caption": caption, "image": image}]))
            t0 = time.time()
            report(job, [{"type": "step", "stepId": step["id"], "status": "started", "cycle": cycle, "etaMs": int(float(step.get("duration", 1)) * 1200)}])
            dwell = driver.act(step)
            events = [{"type": "sensor", "stepId": step["id"], "nodeId": target, "source": step["sensor"], "value": step["expected"], "quality": 0.97}]
            image = driver.camera_snapshot(f"{nodes[target]['name']} · {step['label']}") if not isinstance(driver, DryRunDriver) else driver.camera_snapshot(step["label"], i, total)
            if image:
                events.append({"type": "snapshot", "stepId": step["id"], "nodeId": target, "caption": f"{nodes[target]['name']} · {step['label']}", "image": image})
            events.append({"type": "step", "stepId": step["id"], "status": "complete", "cycle": cycle, "durationMs": int((time.time() - t0) * 1000)})
            report(job, events)
            print(f"  [{cycle}] {step['id']} {step['label']} @ {nodes[target]['name']} · {dwell:.1f}s")
            previous = target
    report(job, [{"type": "complete", "elapsedMs": int((time.time() - started) * 1000)}])


def make_driver():
    if args.dry_run:
        return DryRunDriver()
    from isaac_driver import IsaacDriver  # requiere Isaac Sim (./python.sh)

    return IsaacDriver(args.scenario, headless=args.headless, speed=args.speed, livestream=args.livestream)


def main() -> None:
    driver = make_driver()
    print(f"[executor] {EXECUTOR['name']} → {args.twin} (poll {args.poll}s)")
    try:
        while True:
            try:
                answer = call("/api/isaac/executor/next", {"executor": EXECUTOR})
            except urllib.error.HTTPError as error:
                print(f"[executor] twin respondió {error.code}: {error.read().decode('utf-8', 'ignore')[:160]}")
                driver.idle(max(args.poll, 3.0))
                continue
            except (urllib.error.URLError, TimeoutError) as error:
                print(f"[executor] sin conexión con el twin: {error}")
                driver.idle(max(args.poll, 3.0))
                continue
            mission = answer.get("mission")
            if not mission:
                driver.idle(args.poll)
                continue
            print(f"[executor] misión {mission['jobId']} · {mission['scenarioName']} · {len(mission['steps'])} pasos")
            try:
                run_mission(mission, driver)
                print("[executor] misión completada")
            except MissionClosed as closed:
                print(f"[executor] el twin cerró la misión: {closed}")
            except Exception as error:  # noqa: BLE001
                print(f"[executor] fallo: {error}")
                try:
                    report(mission["jobId"], [{"type": "failed", "reason": str(error)[:200]}])
                except Exception:  # noqa: BLE001
                    pass
            if args.once:
                return
    finally:
        driver.close()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[executor] detenido")
        sys.exit(0)
