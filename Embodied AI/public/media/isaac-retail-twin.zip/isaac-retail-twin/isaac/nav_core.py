# Navegación en el almacén para el ejecutor Digital Twin Robotics (H1 / Go2).
#
# Python puro (sin numpy ni PIL) para que funcione igual dentro de Isaac Sim y en
# el modo --dry-run de cualquier máquina:
#   GridMap      rejilla de ocupación 2D (celdas de `cell` metros) con etiqueta por celda
#   plan_path    A* 8-conexo sobre la rejilla inflada, prefiriendo el centro de los pasillos
#   build_places destinos con nombre ("Rack 3", "Forklift 1", "Start", ...) a partir de
#                los objetos que ocupan la rejilla
#   Follower     controlador que convierte la ruta en comandos (vx, yaw) para la política
#   map_png      PNG RGBA de la rejilla para el minimapa del twin

from __future__ import annotations

import heapq
import math
import struct
import zlib
from collections import deque

SQRT2 = math.sqrt(2.0)
N8 = [(1, 0, 1.0), (-1, 0, 1.0), (0, 1, 1.0), (0, -1, 1.0), (1, 1, SQRT2), (1, -1, SQRT2), (-1, 1, SQRT2), (-1, -1, SQRT2)]

# Palabras clave en la ruta USD de lo que ocupa una celda → tipo de destino.
KINDS = [
    ("rack", ("rack", "shelf", "shelv")),
    ("forklift", ("forklift",)),
    ("pallet", ("pallet", "palette")),
    ("boxes", ("cardbox", "box", "crate", "carton", "bin")),
]
KIND_LABEL = {"rack": "Rack", "forklift": "Forklift", "pallet": "Pallet area", "boxes": "Boxes", "zone": "Zone"}
KIND_LIMIT = {"rack": 12, "forklift": 4, "pallet": 4, "boxes": 4, "zone": 6}
KIND_MIN_CELLS = {"rack": 8, "forklift": 4, "pallet": 4, "boxes": 4, "zone": 24}
IGNORE = ("wall", "floor", "ceiling", "roof", "pillar", "column", "beam", "door", "window", "light", "lamp", "sign", "frame", "stair")


def classify(path: str) -> str | None:
    """Tipo de destino a partir de la ruta USD del objeto (o None si no es un destino)."""
    low = path.lower()
    if any(word in low for word in IGNORE):
        return None
    for kind, words in KINDS:
        if any(word in low for word in words):
            return kind
    return ""  # obstáculo sin tipo conocido


def wrap(angle: float) -> float:
    return (angle + math.pi) % (2 * math.pi) - math.pi


class GridMap:
    def __init__(self, min_x: float, min_y: float, width: int, height: int, cell: float):
        self.min_x, self.min_y, self.w, self.h, self.cell = min_x, min_y, width, height, cell
        self.occ = bytearray(width * height)
        self.kind: list[str | None] = [None] * (width * height)
        self.blocked = bytearray(width * height)
        self.clear: list[int] = [0] * (width * height)
        self.main = bytearray(width * height)  # celdas libres de la región navegable principal

    # ---- coordenadas ---------------------------------------------------------
    def idx(self, i: int, j: int) -> int:
        return j * self.w + i

    def inside(self, i: int, j: int) -> bool:
        return 0 <= i < self.w and 0 <= j < self.h

    def to_cell(self, x: float, y: float) -> tuple[int, int]:
        return int((x - self.min_x) / self.cell), int((y - self.min_y) / self.cell)

    def to_world(self, i: int, j: int) -> tuple[float, float]:
        return self.min_x + (i + 0.5) * self.cell, self.min_y + (j + 0.5) * self.cell

    def bounds(self) -> dict:
        return {"minX": round(self.min_x, 3), "minY": round(self.min_y, 3), "maxX": round(self.min_x + self.w * self.cell, 3), "maxY": round(self.min_y + self.h * self.cell, 3)}

    def mark(self, i: int, j: int, kind: str | None) -> None:
        k = self.idx(i, j)
        self.occ[k] = 1
        if kind and not self.kind[k]:
            self.kind[k] = kind

    # ---- preparación ---------------------------------------------------------
    def prepare(self, robot_radius: float, spawn_hint: tuple[float, float]) -> tuple[float, float]:
        """Distancia a obstáculos, inflado por el radio del robot y región navegable
        principal (la componente libre más grande). Devuelve el punto de spawn: la
        celda de esa región más cercana a `spawn_hint` con holgura cómoda."""
        w, h = self.w, self.h
        self.main = bytearray(w * h)  # re-preparable (otro robot = otro radio)
        far = w + h
        clear = [far] * (w * h)
        queue = deque()
        for k in range(w * h):
            if self.occ[k]:
                clear[k] = 0
                queue.append(k)
        while queue:  # BFS multi-fuente (distancia de Chebyshev en celdas)
            k = queue.popleft()
            i, j = k % w, k // w
            for di, dj, _ in N8:
                ni, nj = i + di, j + dj
                if 0 <= ni < w and 0 <= nj < h:
                    nk = nj * w + ni
                    if clear[nk] > clear[k] + 1:
                        clear[nk] = clear[k] + 1
                        queue.append(nk)
        self.clear = clear
        need = robot_radius / self.cell
        for k in range(w * h):
            self.blocked[k] = 1 if clear[k] < need + 0.5 else 0
        # componentes libres; la más grande es "el almacén"
        seen = bytearray(w * h)
        best: list[int] = []
        for start in range(w * h):
            if self.blocked[start] or seen[start]:
                continue
            comp, queue = [start], deque([start])
            seen[start] = 1
            while queue:
                k = queue.popleft()
                i, j = k % w, k // w
                for di, dj, _ in N8[:4]:
                    ni, nj = i + di, j + dj
                    if 0 <= ni < w and 0 <= nj < h:
                        nk = nj * w + ni
                        if not seen[nk] and not self.blocked[nk]:
                            seen[nk] = 1
                            comp.append(nk)
                            queue.append(nk)
            if len(comp) > len(best):
                best = comp
        for k in best:
            self.main[k] = 1
        if not best:
            raise RuntimeError("the map has no free space for the robot")
        # spawn: piso abierto junto a la zona de racks (lejos de las paredes y con misiones
        # cortas); sin racks, junto a `spawn_hint`. Holgura preferida 2 m, luego 1.5 m, luego 1 m.
        racks = [k for k in range(w * h) if self.kind[k] == "rack"]
        if racks:
            hi, hj = sum(k % w for k in racks) / len(racks), sum(k // w for k in racks) / len(racks)
        else:
            hi, hj = self.to_cell(*spawn_hint)
        candidates = best
        for metres in (2.0, 1.5, 1.0):
            tier = [k for k in best if clear[k] >= max(need + 1, metres / self.cell)]
            if tier:
                candidates = tier
                break
        k = min(candidates, key=lambda c: (c % w - hi) ** 2 + (c // w - hj) ** 2)
        return self.to_world(k % w, k // w)

    def nearest_main(self, x: float, y: float) -> tuple[int, int] | None:
        """Celda navegable más cercana a (x, y) (BFS por toda la rejilla)."""
        i, j = self.to_cell(x, y)
        i, j = min(max(i, 0), self.w - 1), min(max(j, 0), self.h - 1)
        start = self.idx(i, j)
        if self.main[start]:
            return i, j
        seen = bytearray(self.w * self.h)
        seen[start] = 1
        queue = deque([start])
        while queue:
            k = queue.popleft()
            ci, cj = k % self.w, k // self.w
            for di, dj, _ in N8:
                ni, nj = ci + di, cj + dj
                if self.inside(ni, nj):
                    nk = self.idx(ni, nj)
                    if not seen[nk]:
                        if self.main[nk]:
                            return ni, nj
                        seen[nk] = 1
                        queue.append(nk)
        return None

    # ---- línea de vista y A* ---------------------------------------------------
    def line_free(self, a: tuple[int, int], b: tuple[int, int]) -> bool:
        (i0, j0), (i1, j1) = a, b
        di, dj = abs(i1 - i0), abs(j1 - j0)
        si, sj = (1 if i1 > i0 else -1), (1 if j1 > j0 else -1)
        err = di - dj
        while True:
            if not self.inside(i0, j0) or self.blocked[self.idx(i0, j0)]:
                return False
            if (i0, j0) == (i1, j1):
                return True
            e2 = 2 * err
            if e2 > -dj:
                err -= dj
                i0 += si
            if e2 < di:
                err += di
                j0 += sj


def plan_path(grid: GridMap, start_xy: tuple[float, float], goal_xy: tuple[float, float]) -> list[tuple[float, float]] | None:
    """A* sobre la región navegable; devuelve waypoints en metros (suavizados)."""
    start, goal = grid.nearest_main(*start_xy), grid.nearest_main(*goal_xy)
    if start is None or goal is None:
        return None
    w = grid.w
    s, g = grid.idx(*start), grid.idx(*goal)
    gi, gj = goal
    comfy = 1.2 / grid.cell  # >1.2 m de holgura no penaliza: prefiere el centro del pasillo
    open_heap = [(0.0, s)]
    came = {s: -1}
    cost = {s: 0.0}
    while open_heap:
        _, k = heapq.heappop(open_heap)
        if k == g:
            break
        i, j = k % w, k // w
        for di, dj, step in N8:
            ni, nj = i + di, j + dj
            if not grid.inside(ni, nj):
                continue
            nk = nj * w + ni
            if grid.blocked[nk] or not grid.main[nk]:
                continue
            if di and dj and (grid.blocked[j * w + ni] or grid.blocked[nj * w + i]):
                continue  # sin cortar esquinas
            penalty = 1.0 + 1.5 * max(0.0, 1.0 - grid.clear[nk] / comfy)
            new = cost[k] + step * penalty
            if new < cost.get(nk, 1e18):
                cost[nk] = new
                came[nk] = k
                heapq.heappush(open_heap, (new + math.hypot(ni - gi, nj - gj), nk))
    if g not in came:
        return None
    cells = []
    k = g
    while k != -1:
        cells.append((k % w, k // w))
        k = came[k]
    cells.reverse()
    # suavizado por línea de vista
    smooth = [cells[0]]
    anchor = 0
    while anchor < len(cells) - 1:
        nxt = len(cells) - 1
        while nxt > anchor + 1 and not grid.line_free(cells[anchor], cells[nxt]):
            nxt -= 1
        smooth.append(cells[nxt])
        anchor = nxt
    points = [grid.to_world(i, j) for i, j in smooth]
    gc = grid.to_cell(*goal_xy)
    if grid.inside(*gc) and grid.main[grid.idx(*gc)]:
        points[-1] = goal_xy  # el destino exacto es navegable: terminar justo ahí
    return points


# ---- destinos con nombre ----------------------------------------------------

def build_places(grid: GridMap, spawn: tuple[float, float]) -> list[dict]:
    w, h = grid.w, grid.h
    places = [{"id": "start", "name": "Start", "kind": "start", "x": round(spawn[0], 2), "y": round(spawn[1], 2), "heading": 0.0}]
    seen = bytearray(w * h)
    groups: dict[str, list[dict]] = {}
    for start in range(w * h):
        if not grid.occ[start] or seen[start]:
            continue
        comp, queue = [start], deque([start])
        seen[start] = 1
        while queue:
            k = queue.popleft()
            i, j = k % w, k // w
            for di, dj, _ in N8:
                ni, nj = i + di, j + dj
                if 0 <= ni < w and 0 <= nj < h:
                    nk = nj * w + ni
                    if grid.occ[nk] and not seen[nk]:
                        seen[nk] = 1
                        comp.append(nk)
                        queue.append(nk)
        votes: dict[str, int] = {}
        for k in comp:
            kind = grid.kind[k]
            if kind:
                votes[kind] = votes.get(kind, 0) + 1
        kind = max(votes, key=votes.get) if votes else None
        touches_border = any(k % w in (0, w - 1) or k // w in (0, h - 1) for k in comp)
        if not kind:
            if touches_border or len(comp) < KIND_MIN_CELLS["zone"]:
                continue
            kind = "zone"
        if len(comp) < KIND_MIN_CELLS[kind]:
            continue
        cx = sum(grid.to_world(k % w, k // w)[0] for k in comp) / len(comp)
        cy = sum(grid.to_world(k % w, k // w)[1] for k in comp) / len(comp)
        approach = grid.nearest_main(cx, cy)
        if approach is None:
            continue
        ax, ay = grid.to_world(*approach)
        groups.setdefault(kind, []).append({"kind": kind, "x": round(ax, 2), "y": round(ay, 2), "heading": round(math.atan2(cy - ay, cx - ax), 3), "size": len(comp)})
    for kind, items in groups.items():
        items = sorted(items, key=lambda p: -p["size"])[: KIND_LIMIT[kind]]
        items.sort(key=lambda p: (round(p["x"]), p["y"]))
        for n, item in enumerate(items, 1):
            item.pop("size")
            places.append({"id": f"{kind}-{n}", "name": f"{KIND_LABEL[kind]} {n}", **item})
    # zona abierta (máxima holgura) y extremo más lejano del spawn
    main = [k for k in range(w * h) if grid.main[k]]
    if main:
        k = max(main, key=lambda c: grid.clear[c])
        ox, oy = grid.to_world(k % w, k // w)
        places.append({"id": "open-floor", "name": "Open floor", "kind": "open", "x": round(ox, 2), "y": round(oy, 2), "heading": 0.0})
        s = grid.nearest_main(*spawn)
        if s:
            dist = {grid.idx(*s): 0}
            queue = deque([grid.idx(*s)])
            last = grid.idx(*s)
            while queue:
                k = queue.popleft()
                last = k
                i, j = k % w, k // w
                for di, dj, _ in N8[:4]:
                    ni, nj = i + di, j + dj
                    if 0 <= ni < w and 0 <= nj < h:
                        nk = nj * w + ni
                        if grid.main[nk] and nk not in dist:
                            dist[nk] = dist[k] + 1
                            queue.append(nk)
            fx, fy = grid.to_world(last % w, last // w)
            places.append({"id": "far-end", "name": "Far end", "kind": "far", "x": round(fx, 2), "y": round(fy, 2), "heading": 0.0})
    return places


# ---- seguimiento de la ruta -------------------------------------------------

class Follower:
    """Convierte waypoints en (vx, yaw_rate): gira en el sitio si el error de rumbo es
    grande, avanza más rápido cuanto mejor alineado, frena al llegar."""

    def __init__(self, points: list[tuple[float, float]], vmax: float, yaw_max: float, arrive: float = 0.45):
        self.points, self.vmax, self.yaw_max, self.arrive = points, vmax, yaw_max, arrive
        self.target = 1 if len(points) > 1 else 0

    def command(self, x: float, y: float, heading: float) -> tuple[float, float, bool]:
        gx, gy = self.points[-1]
        if math.hypot(gx - x, gy - y) < self.arrive:
            return 0.0, 0.0, True
        while self.target < len(self.points) - 1 and math.hypot(self.points[self.target][0] - x, self.points[self.target][1] - y) < 0.6:
            self.target += 1
        tx, ty = self.points[self.target]
        err = wrap(math.atan2(ty - y, tx - x) - heading)
        yaw = max(-self.yaw_max, min(self.yaw_max, 1.8 * err))
        if abs(err) > 0.9:
            return 0.0, yaw, False
        vx = self.vmax * max(0.0, math.cos(err)) ** 2
        vx = min(vx, 0.35 + 0.6 * math.hypot(gx - x, gy - y))
        return vx, yaw, False


# ---- PNG del minimapa ---------------------------------------------------------

def map_png(grid: GridMap) -> bytes:
    """RGBA: obstáculos en violeta Joule, margen de seguridad lila tenue, zona
    navegable transparente, fuera del almacén gris. Fila 0 = y máxima."""
    w, h = grid.w, grid.h
    rows = bytearray()
    for r in range(h):
        j = h - 1 - r
        rows.append(0)
        for i in range(w):
            k = j * w + i
            if grid.occ[k]:
                rows += bytes((91, 63, 214, 235))
            elif grid.blocked[k]:
                rows += bytes((163, 116, 255, 70))
            elif grid.main[k]:
                rows += bytes((255, 255, 255, 0))
            else:
                rows += bytes((120, 120, 140, 45))

    def chunk(tag: bytes, data: bytes) -> bytes:
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(bytes(rows), 9)) + chunk(b"IEND", b"")


def synthetic_warehouse() -> GridMap:
    """Almacén de prueba para --dry-run: muros, 5 filas de racks, un montacargas,
    pallets y cajas (mismo pipeline que el mapa real de Isaac)."""
    cell = 0.25
    grid = GridMap(-12.0, -8.0, int(24 / cell), int(16 / cell), cell)

    def box(x0, y0, x1, y1, path):
        i0, j0 = grid.to_cell(x0, y0)
        i1, j1 = grid.to_cell(x1, y1)
        for j in range(max(0, j0), min(grid.h, j1 + 1)):
            for i in range(max(0, i0), min(grid.w, i1 + 1)):
                grid.mark(i, j, classify(path))

    box(-12, -8, 12, -7.8, "/World/Warehouse/Wall_S"); box(-12, 7.8, 12, 8, "/World/Warehouse/Wall_N")
    box(-12, -8, -11.8, 8, "/World/Warehouse/Wall_W"); box(11.8, -8, 12, 8, "/World/Warehouse/Wall_E")
    for n, x in enumerate((-8.0, -4.5, -1.0, 2.5, 6.0)):
        box(x, -5.0, x + 1.0, 3.5, f"/World/Warehouse/SM_RackShelf_{n:02d}")
    box(8.5, 4.5, 10.0, 6.5, "/World/Warehouse/Forklift_A")
    box(-10.5, 5.0, -9.0, 6.2, "/World/Warehouse/SM_PaletteA_01")
    box(4.5, 5.2, 5.5, 6.2, "/World/Warehouse/SM_CardBoxA_03")
    box(-2.0, 5.5, -1.4, 6.1, "/World/Warehouse/Pillar_01")
    return grid
