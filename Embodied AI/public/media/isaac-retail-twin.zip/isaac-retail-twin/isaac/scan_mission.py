# Retail Store Twin · Paso 2: misión de escaneo de anaqueles
#
#   ./python.sh /workspace/isaac-retail-twin/isaac/scan_mission.py --mission scan-A1-A5
#   ./python.sh /workspace/isaac-retail-twin/isaac/scan_mission.py --mission scan-A1-A5 --headless --post
#
# El AMR recorre los waypoints de la misión; en cada punto marcado con "scan"
# captura RGB + segmentación semántica de la góndola, cuenta facings por SKU,
# compara contra el planograma (ground truth) y escribe la evidencia en
# evidence/<misión>/. Con --post envía el resultado al puente SAP (sap/bridge.py).

import argparse
import json
import math
import sys
import time
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--mission", default="scan-A1-A5")
parser.add_argument("--headless", action="store_true")
parser.add_argument("--post", action="store_true", help="Enviar resultados al puente SAP")
parser.add_argument("--scenario", default=None)
parser.add_argument("--max-seconds", type=float, default=600.0)
args, _ = parser.parse_known_args()

from isaacsim import SimulationApp

simulation_app = SimulationApp({"headless": args.headless})

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np  # noqa: E402
from isaacsim.core.api import World  # noqa: E402
from isaacsim.robot.wheeled_robots.controllers.differential_controller import DifferentialController  # noqa: E402

from store_scene import ROOT, SCENARIO, attach_shelf_camera, build_store, heading_to, load_scenario, spawn_amr  # noqa: E402

scenario = load_scenario(Path(args.scenario) if args.scenario else SCENARIO)
mission = scenario["missions"][args.mission]
scanner = next(r for r in scenario["robots"] if r["id"] == mission["robot"])

world = World(stage_units_in_meters=1.0)
ground_truth = build_store(world, scenario)
robot_path, robot = spawn_amr(world, scanner)
if robot is None:
    print("[scan_mission] El AMR no se pudo cargar como WheeledRobot; revisa asset_candidates en store.json")
    simulation_app.close()
    sys.exit(1)
camera = attach_shelf_camera(robot_path, scanner)
world.reset()
camera.initialize()
camera.add_semantic_segmentation_to_frame()

controller = DifferentialController(name="diff", wheel_radius=scanner["wheel_radius"], wheel_base=scanner["wheel_base"])
out_dir = ROOT / "evidence" / args.mission
out_dir.mkdir(parents=True, exist_ok=True)
evidence = {"mission": args.mission, "robot": scanner["id"], "site": scenario["sap"]["site"], "started": time.time(), "scans": []}


def yaw_of(quat_wxyz) -> float:
    w, x, y, z = quat_wxyz
    return math.atan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))


def analyze_scan(gondola_id: str, frame: dict) -> dict:
    """Cuenta facings visibles por SKU en la segmentación y compara con el planograma."""
    seg = frame.get("semantic_segmentation") or {}
    info = seg.get("info", {}).get("idToLabels", {})
    data = seg.get("data")
    seen: dict[str, int] = {}
    if data is not None:
        ids, counts = np.unique(np.asarray(data), return_counts=True)
        for i, c in zip(ids, counts):
            lab = info.get(str(int(i)), {}).get("class", "")
            if lab.startswith("product_") and c > 400:  # píxeles mínimos por facing visible
                seen[lab[len("product_"):]] = seen.get(lab[len("product_"):], 0) + 1
    expected: dict[str, int] = {}
    empty: dict[str, int] = {}
    for facing in ground_truth[gondola_id].values():
        expected[facing["sku"]] = expected.get(facing["sku"], 0) + 1
        if not facing["in_stock"]:
            empty[facing["sku"]] = empty.get(facing["sku"], 0) + 1
    return {"gondola": gondola_id, "expected_facings": expected, "empty_facings_truth": empty, "skus_detected": seen}


def capture(gondola_id: str, index: int) -> None:
    for _ in range(3):
        world.step(render=True)
    frame = camera.get_current_frame()
    rgba = camera.get_rgba()
    try:
        from PIL import Image

        Image.fromarray(np.asarray(rgba)[:, :, :3]).save(out_dir / f"{index:02d}_{gondola_id}.png")
    except Exception as error:  # noqa: BLE001
        print(f"[scan_mission] no se guardó la imagen: {error}")
    result = analyze_scan(gondola_id, frame)
    result["t"] = time.time()
    evidence["scans"].append(result)
    print(f"[scan_mission] {gondola_id}: detectados {result['skus_detected']} · vacíos reales {result['empty_facings_truth']}")


waypoints = mission["waypoints"]
speed = mission.get("speed_mps", 0.5)
wp_i, scan_i, t0 = 0, 0, time.time()
while simulation_app.is_running() and wp_i < len(waypoints) and time.time() - t0 < args.max_seconds:
    world.step(render=True)
    pos, quat = robot.get_world_pose()
    target = waypoints[wp_i]
    dx, dy = target["x"] - pos[0], target["y"] - pos[1]
    dist = math.hypot(dx, dy)
    if dist < 0.25:
        if target.get("scan"):
            capture(target["scan"], scan_i)
            scan_i += 1
        wp_i += 1
        continue
    err = (heading_to(pos, (target["x"], target["y"])) - yaw_of(quat) + math.pi) % (2 * math.pi) - math.pi
    lin = speed if abs(err) < 0.35 else 0.0
    ang = max(-1.2, min(1.2, 2.0 * err))
    robot.apply_wheel_actions(controller.forward(command=[lin, ang]))

robot.apply_wheel_actions(controller.forward(command=[0.0, 0.0]))
evidence["finished"] = time.time()
evidence["completed"] = wp_i >= len(waypoints)
(out_dir / "evidence.json").write_text(json.dumps(evidence, indent=2), encoding="utf-8")
print(f"[scan_mission] {'completada' if evidence['completed'] else 'incompleta'} · {len(evidence['scans'])} escaneos · {out_dir}")

if args.post:
    from sap.bridge import post_scan

    print("[scan_mission] puente SAP:", post_scan(scenario["sap"]["bridge_url"], evidence))

simulation_app.close()
