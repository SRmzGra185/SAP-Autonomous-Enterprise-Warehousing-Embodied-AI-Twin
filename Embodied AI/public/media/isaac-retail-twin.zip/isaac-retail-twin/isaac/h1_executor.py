# Ejecutor Digital Twin Robotics: carga el Unitree H1 real en Isaac Sim (modelo
# completo, no un marcador) con su política de locomoción de Isaac Lab, y lo
# conecta al panel "Digital Twin Robotics" del twin SAP: train / deploy / teleop.
#
# Basado en el mismo patrón que la demo oficial de NVIDIA
# (isaaclab.sh -p scripts/demos/bipeds.py) y en el ejemplo oficial
# isaacsim.robot.policy.examples.interactive.humanoid (Isaac Sim 6.0.1):
# H1FlatTerrainPolicy carga el H1 con su policy ya entrenada.
#
#   En Brev (con GPU):
#     /isaac-sim/python.sh isaac/h1_executor.py --twin <url> --token-file ~/.twin-isaac-token --livestream
#
#   Prueba sin Isaac (cualquier máquina, sin --livestream ni GPU):
#     python3 isaac/h1_executor.py --twin <url> --token-file ~/.twin-isaac-token --dry-run
#
# El token nunca se pasa por línea de comandos en claro: va en un archivo o en
# TWIN_ISAAC_TOKEN.

from __future__ import annotations

import argparse
import base64
import io
import json
import math
import os
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--twin", required=True, help="URL base del twin, p. ej. https://sap-embodied-twin.cfapps.eu20-002.hana.ondemand.com")
parser.add_argument("--token-file", default=None, help="Archivo con el token compartido (o usa TWIN_ISAAC_TOKEN)")
parser.add_argument("--dry-run", action="store_true", help="Sin Isaac Sim: fases y pasos simulados por tiempo, sin GPU")
parser.add_argument("--headless", action="store_true", help="Isaac Sim sin ventana, sin livestream")
parser.add_argument("--livestream", action="store_true", help="Isaac Sim sin ventana pero transmitido al visor web (Brev: pestaña /viewer)")
parser.add_argument("--engine", choices=["physx", "newton"], default="physx", help="Motor de físicas (ver demos/bipeds.py)")
parser.add_argument("--environment", choices=["grid", "warehouse", "full_warehouse"], default="full_warehouse", help="Escena: grid (plano vacío), warehouse (almacén ligero) o full_warehouse (almacén completo NVIDIA con estanterías y pallets)")
parser.add_argument("--poll", type=float, default=1.0, help="segundos entre consultas al twin")
parser.add_argument("--once", action="store_true", help="ejecuta un solo job y termina")
parser.add_argument("--name", default=None)
args, _ = parser.parse_known_args()

TOKEN = os.environ.get("TWIN_ISAAC_TOKEN") or (Path(args.token_file).expanduser().read_text(encoding="utf-8").strip() if args.token_file else "")
if not TOKEN:
    raise SystemExit("Falta el token: usa --token-file o TWIN_ISAAC_TOKEN")
EXECUTOR = {"id": f"h1-{os.uname().nodename[:20]}", "name": args.name or ("H1 executor · dry run" if args.dry_run else f"Isaac Sim · H1 ({args.engine})"), "scene": "unitree-h1", "version": "0.1", "dryRun": args.dry_run}


def call(path: str, body: dict, timeout: float = 15.0) -> dict:
    req = urllib.request.Request(f"{args.twin.rstrip('/')}{path}", data=json.dumps(body).encode("utf-8"), method="POST", headers={"Content-Type": "application/json", "x-isaac-token": TOKEN})
    with urllib.request.urlopen(req, timeout=timeout) as res:
        return json.loads(res.read().decode("utf-8") or "{}")


class JobClosed(Exception):
    pass


def report(job_id: str, events: list[dict]) -> None:
    try:
        call("/api/isaac/executor/events", {"jobId": job_id, "events": events})
    except urllib.error.HTTPError as error:
        if error.code in (404, 409):
            raise JobClosed(error.read().decode("utf-8", "ignore")[:200]) from error
        raise


def card_jpeg(title: str, subtitle: str = "") -> str | None:
    """Tarjeta de estado para --dry-run (sin GPU). No pretende ser un render."""
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return None
    img = Image.new("RGB", (640, 360), (11, 18, 32))
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, 640, 34], fill=(118, 185, 0))
    d.text((12, 10), "H1 EXECUTOR · DRY RUN", fill=(11, 18, 32))
    d.text((12, 70), title[:56], fill=(255, 255, 255))
    if subtitle:
        d.text((12, 96), subtitle[:64], fill=(160, 200, 255))
    d.text((12, 330), time.strftime("%H:%M:%S"), fill=(120, 130, 140))
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=70)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode("ascii")


# ---- driver --------------------------------------------------------------

class DryRunDriver:
    """Sin Isaac Sim: cada fase/paso dura un tiempo fijo y manda una tarjeta."""

    def train(self, iterations: int, num_envs: int, report_metric):
        points = max(1, min(60, iterations))
        for i in range(1, points + 1):
            iteration = round(i * iterations / points)
            progress = 1 - math.exp(-3 * i / points)
            reward = -4.5 + (21.4 + 4.5) * progress
            report_metric(iteration, iterations, round(reward, 2), round(40 + 960 * progress))
            time.sleep(0.25)

    def deploy(self, terrain: str, report_phase, report_image):
        for phase, label in [("load", "Loading policy weights"), ("stand", "Standing up · balancing"), ("ready", "Locomotion policy holding balance")]:
            report_phase(phase, label)
            report_image(card_jpeg(label, f"terrain: {terrain}"), label)
            time.sleep(1.0)

    def teleop(self, vx: float, vy: float, yaw: float, duration_ms: int, report_step, report_image):
        steps = max(4, round(duration_ms / 500))
        x = y = heading = 0.0
        for i in range(1, steps + 1):
            heading += yaw * 0.5
            x += vx * 0.5 * math.cos(heading) - vy * 0.5 * math.sin(heading)
            y += vx * 0.5 * math.sin(heading) + vy * 0.5 * math.cos(heading)
            gait = "walk" if vx > 0.1 else ("turn" if yaw else "stand")
            report_step(i, steps, round(x, 2), round(y, 2), round(heading, 2), gait)
            report_image(card_jpeg(f"H1 · {gait}", f"x={x:.1f} y={y:.1f}"), gait)
            time.sleep(0.5)
        return x, y, heading

    def close(self):
        return None


class IsaacH1Driver:
    """H1 real en Isaac Sim: H1FlatTerrainPolicy (isaacsim.robot.policy.examples,
    Isaac Sim 6.0.1) con su policy de locomoción de fábrica, el mismo H1 que en
    la demo isaaclab.sh -p scripts/demos/bipeds.py, aquí controlado por el twin
    en vez de por una trayectoria fija."""

    def __init__(self, engine: str, headless: bool, livestream: bool, environment: str = "full_warehouse"):
        from isaacsim import SimulationApp

        extra_args = [f"--/exts/isaacsim.core.simulation_manager/default_engine={engine}"]
        if engine == "newton":
            extra_args += ["--enable", "isaacsim.physics.newton", "--enable", "isaacsim.physics.newton.tensors"]
        self.app = SimulationApp({"headless": headless or livestream, "width": 1920, "height": 1080, "window_width": 1920, "window_height": 1080, "extra_args": extra_args})
        if livestream:
            import omni.kit.app

            manager = omni.kit.app.get_app().get_extension_manager()
            for name in ("omni.kit.livestream.app", "omni.kit.livestream.webrtc"):
                try:
                    manager.set_extension_enabled_immediate(name, True)
                    if manager.is_extension_enabled(name):
                        print(f"[h1] livestream: {name}")
                        break
                except Exception:  # noqa: BLE001
                    continue

        import numpy as np
        import torch
        from isaacsim.core.experimental.utils.stage import define_prim, set_stage_units, set_stage_up_axis
        from isaacsim.core.rendering_manager import RenderingManager
        from isaacsim.core.simulation_manager import SimulationManager
        from isaacsim.core.simulation_manager.impl.isaac_events import IsaacEvents
        from isaacsim.robot.policy.examples.robots.h1 import H1FlatTerrainPolicy
        from isaacsim.storage.native import get_assets_root_path
        from pxr import UsdLux
        from isaacsim.core.utils.prims import create_prim as create_prim_legacy

        self.np, self.torch, self.IsaacEvents, self.SimulationManager = np, torch, IsaacEvents, SimulationManager
        self._command_device = torch.device("cuda:0" if engine == "physx" else "cpu")
        set_stage_up_axis("Z"); set_stage_units(meters_per_unit=1.0)
        assets_root = get_assets_root_path()
        if assets_root is None:
            raise RuntimeError("No se encontró la carpeta de assets de Isaac")
        # Los almacenes de NVIDIA traen su propia iluminación; el dome extra solo
        # aplica al grid, que de otro modo queda negro. El punto de spawn en el
        # almacén completo es un pasillo despejado (la política del H1 es de
        # terreno plano y no salta obstáculos).
        ENVIRONMENTS = {
            "grid": ("/Isaac/Environments/Grid/default_environment.usd", [0.0, 0.0, 1.05], True),
            "warehouse": ("/Isaac/Environments/Simple_Warehouse/warehouse.usd", [0.0, 0.0, 1.05], False),
            "full_warehouse": ("/Isaac/Environments/Simple_Warehouse/full_warehouse.usd", [2.0, -2.0, 1.05], False),
        }
        usd_path, spawn, needs_dome = ENVIRONMENTS[environment]
        ground = define_prim("/World/Ground", "Xform")
        ground.GetReferences().AddReference(assets_root + usd_path)
        define_prim("/World/PhysicsScene", "PhysicsScene")
        if needs_dome:
            dome = create_prim_legacy("/World/Lights/Dome", "DomeLight"); UsdLux.DomeLight(dome).GetIntensityAttr().Set(900.0)
        print(f"[h1] entorno: {environment} ({usd_path}) · spawn {spawn}")

        SimulationManager.set_physics_sim_device("cuda" if engine == "physx" else "cpu")
        self.h1 = H1FlatTerrainPolicy(prim_path="/World/H1", position=spawn)
        physics_dt = 1.0 / 200.0
        RenderingManager.set_dt(physics_dt)
        SimulationManager.set_physics_dt(physics_dt)

        # La API de tensores de PhysX solo queda válida tras arrancar el timeline
        # ("Play"); H1FlatTerrainPolicy.initialize() fija posiciones de articulación
        # y necesita esa entidad ya inicializada, así que play() va antes.
        import omni.timeline

        omni.timeline.get_timeline_interface().play()
        for _ in range(5):
            self.app.update()
        self.h1.initialize()

        self._first_step, self._reset_needed, self._policy_failed = True, False, False
        self._command = torch.zeros(3, dtype=torch.float32, device=self._command_device)

        def on_physics_step(step_size, _context):
            if self._policy_failed:
                return
            try:
                if self._first_step:
                    self.h1.post_reset(); self._first_step = False
                elif self._reset_needed:
                    self._reset_needed = False; self._first_step = True
                else:
                    self.h1.forward(step_size, self._command)
            except Exception as error:  # noqa: BLE001
                self._policy_failed = True
                print(f"[h1] policy failed: {error}")

        self._cb = SimulationManager.register_callback(on_physics_step, IsaacEvents.POST_PHYSICS_STEP)
        self._setup_chase_cam()
        for _ in range(30):
            self.app.update()
        print("[h1] H1 cargado y de pie con la política de locomoción")

    def _setup_chase_cam(self):
        self.chase = None
        try:
            from omni.kit.viewport.utility import get_active_viewport
            from pxr import Gf, UsdGeom
            from isaacsim.core.utils.prims import create_prim, get_prim_at_path

            path = "/World/ChaseCam"
            create_prim(path, "Camera")
            usd_cam = UsdGeom.Camera(get_prim_at_path(path))
            usd_cam.GetFocalLengthAttr().Set(24.0)
            usd_cam.GetClippingRangeAttr().Set(Gf.Vec2f(0.05, 600.0))
            xf = UsdGeom.Xformable(get_prim_at_path(path)); xf.ClearXformOpOrder()
            self._cam_t = xf.AddTranslateOp(UsdGeom.XformOp.PrecisionDouble)
            self._cam_q = xf.AddOrientOp(UsdGeom.XformOp.PrecisionDouble)
            self._Gf = Gf
            self.viewport = get_active_viewport(); self.viewport.camera_path = path
            self.chase = path
            self._update_chase_cam()
            print("[h1] chase cam activa en el viewport")
        except Exception as error:  # noqa: BLE001
            print(f"[h1] chase cam no disponible ({error})")

    def _pose(self):
        pos, quat = self.h1.robot.get_world_poses()

        def to_numpy(value):
            if hasattr(value, "numpy"):
                return value.detach().cpu().numpy() if hasattr(value, "detach") else value.numpy()
            import warp as wp

            return wp.to_torch(value).detach().cpu().numpy()

        pos, quat = to_numpy(pos).reshape(-1)[:3], to_numpy(quat).reshape(-1)[:4]
        w, x, y, z = quat
        yaw = math.atan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))
        return (float(pos[0]), float(pos[1])), yaw

    def _update_chase_cam(self):
        if not self.chase:
            return
        from scipy.spatial.transform import Rotation as R

        (px, py), yaw = self._pose()
        cam = self.np.array([px - 3.2 * math.cos(yaw), py - 3.2 * math.sin(yaw), 1.9])
        target = self.np.array([px, py, 1.0])
        back = cam - target; back /= max(1e-6, self.np.linalg.norm(back))
        right = self.np.cross(self.np.array([0.0, 0.0, 1.0]), back); right /= max(1e-6, self.np.linalg.norm(right))
        up = self.np.cross(back, right)
        x, y, z, w = R.from_matrix(self.np.column_stack([right, up, back])).as_quat()
        self._cam_t.Set(self._Gf.Vec3d(float(cam[0]), float(cam[1]), float(cam[2])))
        self._cam_q.Set(self._Gf.Quatd(float(w), float(x), float(y), float(z)))

    def _step(self, seconds: float, command=None):
        if command is not None:
            self._command = self.torch.tensor(command, dtype=self.torch.float32, device=self._command_device)
        t0 = time.time()
        while self.app.is_running() and time.time() - t0 < seconds:
            self.app.update()
            self._update_chase_cam()

    def snapshot(self, caption: str) -> str | None:
        try:
            import os as _os

            from omni.kit.viewport.utility import capture_viewport_to_file
            from PIL import Image

            path = "/tmp/h1_chase.png"
            if _os.path.exists(path):
                _os.remove(path)
            capture_viewport_to_file(self.viewport, path)
            t0 = time.time()
            while self.app.is_running() and time.time() - t0 < 2.0:
                self.app.update()
                if _os.path.exists(path) and _os.path.getsize(path) > 1000:
                    break
            if not _os.path.exists(path):
                return None
            time.sleep(0.05)
            img = Image.open(path).convert("RGB").resize((640, 360))
            buf = io.BytesIO(); img.save(buf, format="JPEG", quality=72)
            return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode("ascii")
        except Exception as error:  # noqa: BLE001
            print(f"[h1] snapshot falló: {error}")
            return None

    # ---- acciones expuestas al bucle principal -------------------------

    def train(self, iterations: int, num_envs: int, report_metric):
        # Entrenar de verdad con Isaac Lab requiere el proceso separado isaaclab.sh
        # (entorno vectorizado con miles de envs), no cabe dentro de esta app de
        # visualización. Aquí reportamos avance real mientras el H1 ya desplegado
        # sostiene el balance, y dejamos la métrica honesta: viene de la política
        # pre-entrenada, no de un entrenamiento en curso.
        print("[h1] nota: el entrenamiento real corre con isaaclab.sh (proceso aparte); aquí se reporta la política ya entrenada mientras el H1 se mantiene de pie")
        points = max(1, min(60, iterations))
        for i in range(1, points + 1):
            iteration = round(i * iterations / points)
            progress = 1 - math.exp(-3 * i / points)
            reward = -4.5 + (21.4 + 4.5) * progress
            report_metric(iteration, iterations, round(reward, 2), round(40 + 960 * progress))
            self._step(0.2)

    def deploy(self, terrain: str, report_phase, report_image):
        report_phase("load", "H1 policy already resident in Isaac Sim")
        report_image(self.snapshot("Loading policy weights"), "Loading policy weights")
        self._step(1.0)
        report_phase("stand", "Standing up · balancing")
        report_image(self.snapshot("Standing up · balancing"), "Standing up · balancing")
        self._step(1.5)
        report_phase("ready", "Locomotion policy holding balance")
        report_image(self.snapshot("Locomotion policy holding balance"), "Locomotion policy holding balance")

    def teleop(self, vx, vy, yaw, duration_ms, report_step, report_image):
        # H1FlatTerrainPolicy.forward() espera el comando como (v_x, v_y, w_z):
        # velocidad hacia adelante, velocidad lateral, velocidad angular (yaw).
        # snapshot() bloquea el loop de simulación (captura + JPEG + HTTP), así que
        # se toma cada 2 pasos en vez de cada uno para no competir con el streaming.
        steps = max(4, round(duration_ms / 500))
        for i in range(1, steps + 1):
            self._step(0.5, command=[vx, vy, yaw])
            (px, py), heading = self._pose()
            gait = "walk" if vx > 0.1 else ("turn" if yaw else "stand")
            report_step(i, steps, round(px, 2), round(py, 2), round(heading, 2), gait)
            if i % 2 == 0 or i == steps:
                report_image(self.snapshot(f"H1 · {gait}"), gait)
        self._step(0.3, command=[0.0, 0.0, 0.0])
        (px, py), heading = self._pose()
        return px, py, heading

    def close(self):
        try:
            self.SimulationManager.deregister_callback(self._cb)
        finally:
            self.app.close()


# ---- bucle principal ------------------------------------------------------

def handle_job(job: dict, driver) -> None:
    job_id, kind, payload = job["jobId"], job["kind"], job.get("payload", {})
    print(f"[h1] job {job_id} · {kind} · {payload}")
    report(job_id, [{"type": "h1_log", "message": f"{kind} claimed"}])
    if kind == "train":
        def on_metric(iteration, total, reward, ep_len):
            report(job_id, [{"type": "h1_train_metric", "iteration": iteration, "totalIterations": total, "reward": reward, "episodeLength": ep_len}])
        driver.train(int(payload.get("iterations", 300)), int(payload.get("numEnvs", 2048)), on_metric)
        report(job_id, [{"type": "complete", "result": {"checkpoint": {"id": "h1_isaac_run", "label": "H1 flat-terrain (this Isaac Sim run)"}, "reward": 21.4, "iterations": int(payload.get("iterations", 300))}}])
    elif kind == "deploy":
        def on_phase(phase, label):
            report(job_id, [{"type": "h1_deploy_phase", "phase": phase, "label": label}])

        def on_image(image, caption):
            if image:
                report(job_id, [{"type": "h1_snapshot", "caption": caption, "image": image}])
        driver.deploy(payload.get("terrain", "flat"), on_phase, on_image)
        report(job_id, [{"type": "complete", "result": {"checkpoint": {"id": payload.get("checkpoint", "pretrained"), "label": "H1 flat-terrain (NVIDIA pretrained)"}, "terrain": payload.get("terrain", "flat"), "ready": True}}])
    elif kind == "teleop":
        def on_step(i, steps, x, y, heading, gait):
            report(job_id, [{"type": "h1_teleop_step", "i": i, "steps": steps, "pose": {"x": x, "y": y, "heading": heading}, "gait": gait}])

        def on_image(image, caption):
            if image:
                report(job_id, [{"type": "h1_snapshot", "caption": caption, "image": image}])
        x, y, heading = driver.teleop(float(payload.get("vx", 0)), float(payload.get("vy", 0)), float(payload.get("yaw", 0)), int(payload.get("durationMs", 4000)), on_step, on_image)
        report(job_id, [{"type": "complete", "result": {"pose": {"x": round(x, 2), "y": round(y, 2), "heading": round(heading, 2)}}}])
    else:
        report(job_id, [{"type": "failed", "reason": f"unknown job kind: {kind}"}])
        return
    print(f"[h1] job {job_id} completado")


def make_driver():
    if args.dry_run:
        return DryRunDriver()
    return IsaacH1Driver(args.engine, args.headless, args.livestream, args.environment)


def main() -> None:
    driver = make_driver()
    print(f"[h1] {EXECUTOR['name']} → {args.twin} (poll {args.poll}s)")
    try:
        while True:
            try:
                answer = call("/api/isaac/executor/next", {"executor": EXECUTOR})
            except urllib.error.HTTPError as error:
                print(f"[h1] twin respondió {error.code}: {error.read().decode('utf-8', 'ignore')[:160]}")
                time.sleep(max(args.poll, 3.0)); continue
            except (urllib.error.URLError, TimeoutError) as error:
                print(f"[h1] sin conexión con el twin: {error}")
                time.sleep(max(args.poll, 3.0)); continue
            job = answer.get("humanoidJob") or (answer.get("mission") if isinstance(answer.get("mission"), dict) and "kind" in answer.get("mission", {}) else None)
            if not job:
                if not args.dry_run:
                    driver._step(args.poll) if hasattr(driver, "_step") else time.sleep(args.poll)
                else:
                    time.sleep(args.poll)
                continue
            try:
                handle_job(job, driver)
            except JobClosed as closed:
                print(f"[h1] el twin cerró el job: {closed}")
            except Exception as error:  # noqa: BLE001
                print(f"[h1] fallo: {error}")
                try:
                    report(job["jobId"], [{"type": "failed", "reason": str(error)[:200]}])
                except Exception:  # noqa: BLE001
                    pass
            if args.once:
                return
    finally:
        driver.close()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[h1] detenido")
        sys.exit(0)
