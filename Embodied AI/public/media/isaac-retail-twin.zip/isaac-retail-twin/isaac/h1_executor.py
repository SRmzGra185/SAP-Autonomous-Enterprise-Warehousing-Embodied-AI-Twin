# Ejecutor Digital Twin Robotics: carga un robot real de Unitree en Isaac Sim
# (humanoide H1 o cuadrúpedo Go2, cada uno con su política de locomoción oficial de
# NVIDIA) dentro de un almacén de NVIDIA, y lo conecta al panel "Digital Twin
# Robotics" del twin SAP: train / deploy / teleop / navigate / camera / plan.
#
#   - deploy:   cambia de robot (h1 | go2) o de almacén y lo pone de pie
#   - teleop:   comando de velocidad (vx, vy, yaw) por un tiempo
#   - navigate: ir a un destino con nombre ("Rack 3", "Forklift 1", ...) esquivando
#               estanterías (mapa PhysX + A*, ver nav_core.py)
#   - camera:   vista chase / wide / top / inspect (foto del rack para Joule), y "find robot"
#   - plan:     secuencia de pasos que arma Joule en el twin
#
#   En Brev (con GPU):
#     /isaac-sim/python.sh -u isaac/h1_executor.py --twin <url> --token-file ~/.twin-isaac-token --livestream
#
#   Prueba sin Isaac (cualquier máquina, sin GPU): mismo protocolo sobre un almacén sintético
#     python3 isaac/h1_executor.py --twin <url> --token-file ~/.twin-isaac-token --dry-run
#
# El token nunca se pasa por línea de comandos en claro: va en un archivo o en
# TWIN_ISAAC_TOKEN.

from __future__ import annotations

import argparse
import base64
import io
import json
import math
import os
import sys
import time
import urllib.error
import urllib.request
from importlib import import_module
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from nav_core import Follower, GridMap, build_places, classify, map_png, plan_path, synthetic_warehouse, wrap  # noqa: E402

# Robots soportados: clase de política oficial de isaacsim.robot.policy.examples.robots
# (Isaac Sim 6.0.1), altura de spawn, radio para el mapa, límites de velocidad dentro
# del rango de entrenamiento, altura bajo la cual se considera caído y cámaras
# (distancia atrás, altura, altura del punto al que mira[, cuánto adelante mira, desplazamiento
# lateral]). "inspect" va sobre el hombro y mira al frente: la foto del rack que Joule revisa.
ROBOTS = {
    "h1": {"label": "Unitree H1", "kind": "humanoid", "module": "isaacsim.robot.policy.examples.robots.h1", "cls": "H1FlatTerrainPolicy",
           "z": 1.05, "radius": 0.40, "vmax": 0.8, "yaw_max": 1.0, "fall_z": 0.55, "task": "Isaac-Velocity-Flat-H1-v0",
           "cam": {"chase": (4.2, 2.4, 1.0), "wide": (8.5, 5.8, 0.6), "top": (0.4, 16.0, 0.0), "inspect": (0.9, 1.9, 1.0, 2.4, 0.55)}},
    "go2": {"label": "Unitree Go2", "kind": "quadruped", "module": "isaacsim.robot.policy.examples.robots.go2", "cls": "Go2FlatTerrainPolicy",
            "z": 0.45, "radius": 0.45, "vmax": 0.7, "yaw_max": 0.8, "fall_z": 0.14, "task": "Isaac-Velocity-Flat-Unitree-Go2-v0",
            "cam": {"chase": (2.6, 1.4, 0.3), "wide": (6.8, 4.4, 0.3), "top": (0.4, 13.0, 0.0), "inspect": (0.6, 1.1, 0.7, 2.2, 0.35)}},
}
# Almacenes de NVIDIA (assets públicos de Isaac 6.0) y punto de spawn sugerido; el
# spawn real es la celda libre más cercana con holgura, calculada sobre el mapa.
ENVIRONMENTS = {
    "full_warehouse": ("Full warehouse", "/Isaac/Environments/Simple_Warehouse/full_warehouse.usd", (2.0, -2.0), False),
    "warehouse_shelves": ("Warehouse · multiple shelves", "/Isaac/Environments/Simple_Warehouse/warehouse_multiple_shelves.usd", (0.0, 0.0), False),
    "warehouse_forklifts": ("Warehouse · forklifts", "/Isaac/Environments/Simple_Warehouse/warehouse_with_forklifts.usd", (0.0, 0.0), False),
    "warehouse": ("Simple warehouse", "/Isaac/Environments/Simple_Warehouse/warehouse.usd", (0.0, 0.0), False),
    "grid": ("Empty grid", "/Isaac/Environments/Grid/default_environment.usd", (0.0, 0.0), True),
}
ROBOT_PATH, GROUND_PATH, DOME_PATH, CAM_PATH = "/World/Robot", "/World/Ground", "/World/Lights/Dome", "/World/ChaseCam"
VIEWS = ("chase", "wide", "top", "inspect")

parser = argparse.ArgumentParser()
parser.add_argument("--twin", required=True, help="URL base del twin, p. ej. https://sap-embodied-twin.cfapps.eu20-002.hana.ondemand.com")
parser.add_argument("--token-file", default=None, help="Archivo con el token compartido (o usa TWIN_ISAAC_TOKEN)")
parser.add_argument("--dry-run", action="store_true", help="Sin Isaac Sim: almacén sintético y cinemática simple, sin GPU")
parser.add_argument("--headless", action="store_true", help="Isaac Sim sin ventana, sin livestream")
parser.add_argument("--livestream", action="store_true", help="Isaac Sim sin ventana pero transmitido al visor web (Brev: pestaña /viewer)")
parser.add_argument("--engine", choices=["physx", "newton"], default="physx", help="Motor de físicas (ver demos/bipeds.py)")
parser.add_argument("--robot", choices=sorted(ROBOTS), default="h1", help="Robot inicial (se puede cambiar desde el twin con Deploy)")
parser.add_argument("--environment", choices=list(ENVIRONMENTS), default="full_warehouse", help="Almacén inicial (se puede cambiar desde el twin con Deploy)")
parser.add_argument("--render-steps", type=int, default=4, help="pasos de física (1/200 s) por frame renderizado; el ejemplo oficial del H1 usa 8")
parser.add_argument("--poll", type=float, default=1.0, help="segundos entre consultas al twin")
parser.add_argument("--once", action="store_true", help="ejecuta un solo job y termina")
parser.add_argument("--name", default=None)
args, _ = parser.parse_known_args()

TOKEN = os.environ.get("TWIN_ISAAC_TOKEN") or (Path(args.token_file).expanduser().read_text(encoding="utf-8").strip() if args.token_file else "")
if not TOKEN:
    raise SystemExit("Falta el token: usa --token-file o TWIN_ISAAC_TOKEN")
EXECUTOR = {"id": f"h1-{os.uname().nodename[:20]}", "name": args.name or ("Robot executor · dry run" if args.dry_run else f"Isaac Sim · Unitree ({args.engine})"), "scene": "unitree-warehouse", "version": "0.3", "dryRun": args.dry_run}


def log(message: str) -> None:
    print(f"[h1] {message}", flush=True)


def call(path: str, body: dict, timeout: float = 15.0) -> dict:
    req = urllib.request.Request(f"{args.twin.rstrip('/')}{path}", data=json.dumps(body).encode("utf-8"), method="POST", headers={"Content-Type": "application/json", "x-isaac-token": TOKEN})
    with urllib.request.urlopen(req, timeout=timeout) as res:
        return json.loads(res.read().decode("utf-8") or "{}")


class JobClosed(Exception):
    pass


def report(job_id: str, events: list[dict]) -> None:
    try:
        call("/api/isaac/executor/events", {"jobId": job_id, "events": events})
    except urllib.error.HTTPError as error:
        if error.code in (404, 409):
            raise JobClosed(error.read().decode("utf-8", "ignore")[:200]) from error
        raise


def card_jpeg(title: str, subtitle: str = "") -> str | None:
    """Tarjeta de estado para --dry-run (sin GPU). No pretende ser un render."""
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return None
    img = Image.new("RGB", (640, 360), (26, 15, 94))
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, 640, 34], fill=(91, 63, 214))
    d.text((12, 10), "ROBOT EXECUTOR · DRY RUN", fill=(255, 255, 255))
    d.text((12, 70), title[:56], fill=(255, 255, 255))
    if subtitle:
        d.text((12, 96), subtitle[:64], fill=(221, 214, 254))
    d.text((12, 330), time.strftime("%H:%M:%S"), fill=(167, 139, 250))
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=70)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode("ascii")


# ---- lógica común a los dos drivers -------------------------------------------

class RobotBase:
    """Mapa, destinos, navegación y planes: idéntico con Isaac o en --dry-run. Cada
    driver solo implementa _pose(), _height(), _advance(), snapshot() y configure()."""

    robot_id = "h1"
    environment = ""
    grid: GridMap | None = None
    places: list[dict] = []
    spawn = (0.0, 0.0)
    map_version = 0
    view = "chase"

    @property
    def spec(self) -> dict:
        return ROBOTS[self.robot_id]

    def status(self) -> dict:
        try:
            (x, y), heading = self._pose()
            pose = {"x": round(x, 2), "y": round(y, 2), "heading": round(heading, 3)}
        except Exception:  # noqa: BLE001
            pose = None
        return {"robot": self.robot_id, "robotLabel": self.spec["label"], "environment": self.environment, "pose": pose, "mapVersion": self.map_version, "view": self.view}

    def _prepare_map(self) -> None:
        self.spawn = self.grid.prepare(self.spec["radius"], ENVIRONMENTS[self.environment][2])
        self.places = build_places(self.grid, self.spawn)
        self.map_version += 1
        self._upload_map()
        log(f"mapa v{self.map_version}: {self.grid.w}x{self.grid.h} celdas de {self.grid.cell} m · {len(self.places)} destinos: {', '.join(p['name'] for p in self.places)}")

    def _upload_map(self) -> None:
        body = {"executorId": EXECUTOR["id"], "version": self.map_version, "robot": self.robot_id, "environment": self.environment, "environmentLabel": ENVIRONMENTS[self.environment][0],
                "cell": self.grid.cell, "width": self.grid.w, "height": self.grid.h, "bounds": self.grid.bounds(), "spawn": {"x": round(self.spawn[0], 2), "y": round(self.spawn[1], 2)},
                "image": "data:image/png;base64," + base64.b64encode(map_png(self.grid)).decode("ascii"), "places": self.places}
        try:
            call("/api/isaac/executor/map", body)
        except Exception as error:  # noqa: BLE001
            log(f"no se pudo subir el mapa al twin: {error}")

    def place(self, target) -> dict | None:
        if isinstance(target, dict) and "x" in target and "y" in target:
            return {"id": "point", "name": f"({float(target['x']):.1f}, {float(target['y']):.1f})", "x": float(target["x"]), "y": float(target["y"]), "heading": None}
        key = str(target or "").strip().lower()
        return next((p for p in self.places if p["id"] == key or p["name"].lower() == key), None)

    # ---- acciones -------------------------------------------------------------
    def teleop(self, vx, vy, yaw, duration_ms, on_step, on_image):
        steps = max(4, round(duration_ms / 500))
        for i in range(1, steps + 1):
            self._advance(0.5, command=[vx, vy, yaw])
            (px, py), heading = self._pose()
            gait = "walk" if abs(vx) > 0.1 or abs(vy) > 0.1 else ("turn" if yaw else "stand")
            on_step(i, steps, px, py, heading, gait)
            if i % 2 == 0 or i == steps:
                on_image(self.snapshot(f"{self.spec['label']} · {gait}"), gait)
        self._advance(0.3, command=[0.0, 0.0, 0.0])
        (px, py), heading = self._pose()
        return {"pose": {"x": round(px, 2), "y": round(py, 2), "heading": round(heading, 3)}}

    def navigate(self, target, on_step, on_image, on_path):
        goal = self.place(target)
        if not goal:
            return {"reached": False, "reason": f"unknown destination: {target}"}
        spec = self.spec
        (x, y), heading = self._pose()
        path = plan_path(self.grid, (x, y), (goal["x"], goal["y"]))
        if not path:
            return {"reached": False, "place": goal["name"], "reason": "no route to that destination"}
        on_path(path, goal)
        follower = Follower(path, spec["vmax"], spec["yaw_max"])
        state = {"done": False}

        def steer():
            (cx, cy), ch = self._pose()
            vx, yaw, done = follower.command(cx, cy, ch)
            state["done"] = done
            self._set_command([vx, 0.0, yaw] if not done else [0.0, 0.0, 0.0])
            return vx, yaw

        t = 0.0
        last_step = last_snap = 0.0
        anchor, anchor_t, replans, reason = (x, y), 0.0, 0, None
        step_i = 0
        while True:
            vx, yaw = steer()
            if state["done"]:
                break
            if self._height() < spec["fall_z"]:
                reason = "the robot fell"
                break
            if t > 180.0:
                reason = "timeout"
                break
            self._advance(0.1, on_update=steer)
            t += 0.1
            (x, y), heading = self._pose()
            if math.hypot(x - anchor[0], y - anchor[1]) > 0.3:
                anchor, anchor_t = (x, y), t
            elif t - anchor_t > 8.0:  # sin avance: re-planificar desde donde está
                replans += 1
                if replans > 3:
                    reason = "blocked"
                    break
                path = plan_path(self.grid, (x, y), (goal["x"], goal["y"]))
                if not path:
                    reason = "no route from here"
                    break
                on_path(path, goal)
                follower = Follower(path, spec["vmax"], spec["yaw_max"])
                anchor, anchor_t = (x, y), t
            if t - last_step >= 0.5:
                last_step = t
                step_i += 1
                gait = "walk" if vx > 0.1 else "turn"
                on_step(step_i, 0, x, y, heading, gait)
            if t - last_snap >= 2.0:
                last_snap = t
                on_image(self.snapshot(f"{spec['label']} → {goal['name']}", on_update=steer), f"→ {goal['name']}")
        self._set_command([0.0, 0.0, 0.0])
        self._advance(0.4)
        if reason is None and goal.get("heading") is not None:  # de frente al objeto
            for _ in range(40):
                (x, y), heading = self._pose()
                err = wrap(goal["heading"] - heading)
                if abs(err) < 0.15:
                    break
                self._advance(0.1, command=[0.0, 0.0, max(-0.8, min(0.8, 1.6 * err))])
            self._advance(0.3, command=[0.0, 0.0, 0.0])
        if reason == "the robot fell":  # de pie otra vez en el inicio, para que la demo siga
            on_image(self.snapshot(f"{spec['label']} · fell"), "fell")
            self.recover()
            reason = "the robot fell · reset at the start"
        (x, y), heading = self._pose()
        on_step(step_i + 1, 0, x, y, heading, "stand")
        on_image(self.snapshot(f"{spec['label']} at {goal['name']}" if reason is None else f"{spec['label']} · {reason}"), goal["name"])
        return {"reached": reason is None, "place": goal["name"], "placeId": goal.get("id"), "reason": reason, "seconds": round(t, 1), "pose": {"x": round(x, 2), "y": round(y, 2), "heading": round(heading, 3)}}

    def camera(self, view: str, on_image):
        self.view = view if view in VIEWS else "chase"
        self._apply_camera(reassign=True)
        self._advance(0.8 if self.view == "inspect" else 0.3, command=[0.0, 0.0, 0.0] if self.view == "inspect" else None)  # quieto para la foto
        on_image(self.snapshot(f"{self.spec['label']} · {self.view} view"), f"{self.view} view")
        return {"view": self.view}

    def recover(self):
        """Vuelve a poner el robot de pie en el inicio (mismo robot y almacén, sin recargar la escena)."""
        log(f"{self.spec['label']} se cayó: reinicio en el punto de inicio")
        self.configure(self.robot_id, self.environment)

    # ganchos por driver
    def _set_command(self, command):
        raise NotImplementedError

    def _apply_camera(self, reassign: bool = False):
        return None


class DryRunDriver(RobotBase):
    """Sin Isaac Sim: almacén sintético (mismo pipeline de mapa y A*) y una
    cinemática de uniciclo; las tarjetas sustituyen a las fotos del viewport."""

    def __init__(self, robot: str, environment: str):
        self._x = self._y = self._th = 0.0
        self._cmd = [0.0, 0.0, 0.0]
        self.configure(robot, environment)

    def configure(self, robot, environment, phase=None):
        phase = phase or (lambda p, label: log(f"{p}: {label}"))
        if environment != self.environment or self.grid is None:
            phase("scene", f"Loading {ENVIRONMENTS[environment][0]} (synthetic)")
            self.grid, self.environment = synthetic_warehouse(), environment
            phase("map", "Mapping the warehouse")
        self.robot_id = robot
        self._prepare_map()
        phase("spawn", f"Spawning {self.spec['label']}")
        self._x, self._y, self._th = self.spawn[0], self.spawn[1], 0.0
        time.sleep(0.5)
        phase("ready", f"{self.spec['label']} standing · {ENVIRONMENTS[environment][0]}")

    def _pose(self):
        return (self._x, self._y), self._th

    def _height(self):
        return self.spec["z"]

    def _set_command(self, command):
        self._cmd = list(command)

    def _advance(self, seconds: float, command=None, on_update=None):
        if command is not None:
            self._set_command(command)
        for _ in range(max(1, round(seconds / 0.05))):
            if on_update:
                on_update()
            vx, vy, yaw = self._cmd
            self._th = wrap(self._th + yaw * 0.05)
            self._x += (vx * math.cos(self._th) - vy * math.sin(self._th)) * 0.05
            self._y += (vx * math.sin(self._th) + vy * math.cos(self._th)) * 0.05
            time.sleep(0.01)  # 5x más rápido que tiempo real

    def snapshot(self, caption: str, on_update=None):
        return card_jpeg(caption, f"x={self._x:.1f} y={self._y:.1f} · {self.view} view")

    def close(self):
        return None


class IsaacDriver(RobotBase):
    """Robot real en Isaac Sim 6.0.1: H1FlatTerrainPolicy / Go2FlatTerrainPolicy
    (isaacsim.robot.policy.examples) con su política de fábrica, dentro de un
    almacén de NVIDIA mapeado con consultas de solapamiento de PhysX."""

    def __init__(self, engine: str, headless: bool, livestream: bool, robot: str, environment: str, render_steps: int):
        from isaacsim import SimulationApp

        extra_args = [f"--/exts/isaacsim.core.simulation_manager/default_engine={engine}"]
        if engine == "newton":
            extra_args += ["--enable", "isaacsim.physics.newton", "--enable", "isaacsim.physics.newton.tensors"]
        self.app = SimulationApp({"headless": headless or livestream, "width": 1920, "height": 1080, "window_width": 1920, "window_height": 1080, "extra_args": extra_args})
        if livestream:
            import omni.kit.app

            manager = omni.kit.app.get_app().get_extension_manager()
            for name in ("omni.kit.livestream.app", "omni.kit.livestream.webrtc"):
                try:
                    manager.set_extension_enabled_immediate(name, True)
                    if manager.is_extension_enabled(name):
                        log(f"livestream: {name}")
                        break
                except Exception:  # noqa: BLE001
                    continue

        import numpy as np
        import omni.timeline
        import omni.usd
        import torch
        from isaacsim.core.experimental.utils.stage import define_prim, set_stage_units, set_stage_up_axis
        from isaacsim.core.rendering_manager import RenderingManager
        from isaacsim.core.simulation_manager import SimulationManager
        from isaacsim.core.simulation_manager.impl.isaac_events import IsaacEvents
        from isaacsim.storage.native import get_assets_root_path

        self.np, self.torch, self.IsaacEvents, self.SimulationManager, self.define_prim = np, torch, IsaacEvents, SimulationManager, define_prim
        self.timeline, self.usd = omni.timeline.get_timeline_interface(), omni.usd
        self._command_device = torch.device("cuda:0" if engine == "physx" else "cpu")
        self._command = torch.zeros(3, dtype=torch.float32, device=self._command_device)
        self._cb, self.policy, self.chase, self.viewport = None, None, None, None
        self._cam_yaw = None
        set_stage_up_axis("Z")
        set_stage_units(meters_per_unit=1.0)
        self.assets_root = get_assets_root_path()
        if self.assets_root is None:
            raise RuntimeError("No se encontró la carpeta de assets de Isaac")
        # Física a 200 Hz como el entrenamiento; varios pasos de física por frame
        # renderizado (el ejemplo oficial h1_standalone usa rendering_dt = 8/200).
        self.physics_dt = 1.0 / 200.0
        self.render_dt = self.physics_dt * max(1, render_steps)
        SimulationManager.set_physics_sim_device("cuda" if engine == "physx" else "cpu")
        SimulationManager.set_physics_dt(self.physics_dt)
        RenderingManager.set_dt(self.render_dt)
        self.configure(robot, environment)
        t0, n = time.time(), 0
        while time.time() - t0 < 2.0:
            self.app.update()
            n += 1
        log(f"velocidad de simulación ≈ {n * self.render_dt / 2.0:.2f}x tiempo real ({n / 2.0:.0f} fps, {self.render_dt * 1000:.0f} ms por frame)")

    # ---- utilidades de escena -------------------------------------------------
    def _stage(self):
        return self.usd.get_context().get_stage()

    def _updates(self, n: int):
        for _ in range(n):
            self.app.update()

    def _wait_loaded(self, timeout: float = 240.0):
        ctx, t0, stable = self.usd.get_context(), time.time(), 0
        while time.time() - t0 < timeout:
            self.app.update()
            try:
                _, loaded, total = ctx.get_stage_loading_status()
                busy = total > 0 and loaded < total
            except Exception:  # noqa: BLE001
                busy = time.time() - t0 < 8.0
            stable = 0 if busy else stable + 1
            if stable > 30 and time.time() - t0 > 3.0:
                return
        log("aviso: el almacén sigue cargando tras el tiempo límite; se continúa")

    def _remove(self, path: str):
        stage = self._stage()
        if stage.GetPrimAtPath(path).IsValid():
            stage.RemovePrim(path)

    # ---- mapa del almacén (PhysX) ---------------------------------------------
    def _scan_map(self) -> GridMap:
        from pxr import Usd, UsdGeom

        stage = self._stage()
        cache = UsdGeom.BBoxCache(Usd.TimeCode.Default(), [UsdGeom.Tokens.default_, UsdGeom.Tokens.render], useExtentsHint=True)
        rng = cache.ComputeWorldBound(stage.GetPrimAtPath(GROUND_PATH)).ComputeAlignedRange()
        if rng.IsEmpty():
            min_x, min_y, max_x, max_y = -15.0, -15.0, 15.0, 15.0
        else:
            lo, hi = rng.GetMin(), rng.GetMax()
            min_x, min_y, max_x, max_y = float(lo[0]), float(lo[1]), float(hi[0]), float(hi[1])
        cx, cy = (min_x + max_x) / 2, (min_y + max_y) / 2
        half_x, half_y = min(45.0, (max_x - min_x) / 2 + 0.5), min(45.0, (max_y - min_y) / 2 + 0.5)
        if max_x - min_x > 90 or max_y - min_y > 90:  # suelo infinito (grid): solo alrededor del origen
            cx, cy, half_x, half_y = 0.0, 0.0, 15.0, 15.0
        cell = 0.25 if half_x * half_y * 4 <= 2500 else 0.4
        grid = GridMap(cx - half_x, cy - half_y, int(2 * half_x / cell), int(2 * half_y / cell), cell)
        hits = self._scan_physx(grid, 0.08, 1.25)
        total = grid.w * grid.h
        if hits > 0.85 * total:  # el suelo cuenta como obstáculo: subir la banda
            grid = GridMap(grid.min_x, grid.min_y, grid.w, grid.h, cell)
            hits = self._scan_physx(grid, 0.25, 1.25)
        if hits == 0:
            log("PhysX no reportó colisiones en la banda del robot; se usan cajas envolventes USD")
            hits = self._scan_bboxes(grid, stage, cache)
        log(f"mapa: {hits} de {total} celdas ocupadas")
        return grid

    def _scan_physx(self, grid: GridMap, z0: float, z1: float) -> int:
        try:
            import carb
            from omni.physx import get_physx_scene_query_interface
        except Exception as error:  # noqa: BLE001
            log(f"sin consultas PhysX ({error})")
            return 0
        query = get_physx_scene_query_interface()
        half = carb.Float3(grid.cell / 2, grid.cell / 2, (z1 - z0) / 2)
        rot, zc = carb.Float4(0.0, 0.0, 0.0, 1.0), (z0 + z1) / 2
        found: list[str] = []

        def on_hit(hit) -> bool:
            path = str(getattr(hit, "collision", "") or getattr(hit, "rigid_body", "") or "")
            if path.startswith(ROBOT_PATH):
                return True
            found.append(path)
            return False

        count = 0
        try:
            for j in range(grid.h):
                for i in range(grid.w):
                    x, y = grid.to_world(i, j)
                    found.clear()
                    query.overlap_box(half, carb.Float3(x, y, zc), rot, on_hit, False)
                    if found:
                        grid.mark(i, j, classify(found[0]))
                        count += 1
        except Exception as error:  # noqa: BLE001
            log(f"consulta PhysX falló ({error})")
            return 0
        return count

    def _scan_bboxes(self, grid: GridMap, stage, cache) -> int:
        from pxr import Usd, UsdGeom

        count = 0
        for prim in Usd.PrimRange(stage.GetPrimAtPath(GROUND_PATH), Usd.TraverseInstanceProxies()):
            if not prim.IsA(UsdGeom.Gprim):
                continue
            rng = cache.ComputeWorldBound(prim).ComputeAlignedRange()
            if rng.IsEmpty():
                continue
            lo, hi = rng.GetMin(), rng.GetMax()
            if hi[2] < 0.15 or lo[2] > 1.4 or (hi[0] - lo[0]) * (hi[1] - lo[1]) > 80:
                continue
            kind = classify(str(prim.GetPath()))
            i0, j0 = grid.to_cell(lo[0], lo[1])
            i1, j1 = grid.to_cell(hi[0], hi[1])
            for j in range(max(0, j0), min(grid.h, j1 + 1)):
                for i in range(max(0, i0), min(grid.w, i1 + 1)):
                    if not grid.occ[grid.idx(i, j)]:
                        count += 1
                    grid.mark(i, j, kind)
        return count

    # ---- robot ----------------------------------------------------------------
    def configure(self, robot: str, environment: str, phase=None):
        """(Re)carga almacén y/o robot. Mismo camino para el arranque, para cambiar de
        robot o de almacén y para "reset" (volver a poner el robot en el inicio)."""
        phase = phase or (lambda p, label: log(f"{p}: {label}"))
        if self._cb is not None:
            self.SimulationManager.deregister_callback(self._cb)
            self._cb = None
        self.timeline.stop()
        self._updates(3)
        self._remove(ROBOT_PATH)
        self.policy = None
        self._updates(2)
        if environment != self.environment or self.grid is None:
            label, usd, _, needs_dome = ENVIRONMENTS[environment]
            phase("scene", f"Loading {label}")
            self._remove(GROUND_PATH)
            self._remove(DOME_PATH)
            ground = self.define_prim(GROUND_PATH, "Xform")
            ground.GetReferences().AddReference(self.assets_root + usd)
            if not self._stage().GetPrimAtPath("/World/PhysicsScene").IsValid():
                self.define_prim("/World/PhysicsScene", "PhysicsScene")
            if needs_dome:
                from pxr import UsdLux

                UsdLux.DomeLight.Define(self._stage(), DOME_PATH).GetIntensityAttr().Set(900.0)
            self._wait_loaded()
            phase("map", "Mapping the warehouse with PhysX")
            self.timeline.play()
            self._updates(10)
            self.grid, self.environment = self._scan_map(), environment
            self.timeline.stop()
            self._updates(3)
        self.robot_id = robot
        self._prepare_map()
        spec = self.spec
        phase("spawn", f"Spawning {spec['label']} at the start point")
        cls = getattr(import_module(spec["module"]), spec["cls"])
        self.policy = cls(prim_path=ROBOT_PATH, position=[self.spawn[0], self.spawn[1], spec["z"]])
        # La API de tensores de PhysX solo queda válida tras "Play": initialize()
        # fija posiciones de articulación y necesita esa entidad ya inicializada.
        self.timeline.play()
        self._updates(5)
        self.policy.initialize()
        self._first_step, self._reset_needed, self._policy_failed = True, False, False
        self._command = self.torch.zeros(3, dtype=self.torch.float32, device=self._command_device)

        def on_physics_step(step_size, _context):
            if self._policy_failed or self.policy is None:
                return
            try:
                if self._first_step:
                    self.policy.post_reset()
                    self._first_step = False
                else:
                    self.policy.forward(step_size, self._command)
            except Exception as error:  # noqa: BLE001
                self._policy_failed = True
                log(f"policy failed: {error}")

        self._cb = self.SimulationManager.register_callback(on_physics_step, self.IsaacEvents.POST_PHYSICS_STEP)
        self._cam_yaw = None
        self._apply_camera(reassign=True)
        self._updates(30)
        phase("ready", f"{spec['label']} standing · {ENVIRONMENTS[self.environment][0]}")

    def _to_numpy(self, value):
        if hasattr(value, "numpy"):
            return value.detach().cpu().numpy() if hasattr(value, "detach") else value.numpy()
        import warp as wp

        return wp.to_torch(value).detach().cpu().numpy()

    def _raw_pose(self):
        pos, quat = self.policy.robot.get_world_poses()
        return self._to_numpy(pos).reshape(-1)[:3], self._to_numpy(quat).reshape(-1)[:4]

    def _pose(self):
        pos, quat = self._raw_pose()
        w, x, y, z = quat
        return (float(pos[0]), float(pos[1])), math.atan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))

    def _height(self):
        return float(self._raw_pose()[0][2])

    def _set_command(self, command):
        self._command = self.torch.tensor(command, dtype=self.torch.float32, device=self._command_device)

    def _advance(self, seconds: float, command=None, on_update=None):
        """Avanza `seconds` de tiempo de simulación (no de reloj)."""
        if command is not None:
            self._set_command(command)
        for _ in range(max(1, round(seconds / self.render_dt))):
            if not self.app.is_running():
                return
            if on_update:
                on_update()
            self.app.update()
            self._update_camera()

    # ---- cámara ---------------------------------------------------------------
    def _apply_camera(self, reassign: bool = False):
        try:
            from omni.kit.viewport.utility import get_active_viewport
            from pxr import Gf, UsdGeom

            stage = self._stage()
            if not stage.GetPrimAtPath(CAM_PATH).IsValid():
                cam = UsdGeom.Camera.Define(stage, CAM_PATH)
                cam.GetFocalLengthAttr().Set(22.0)
                cam.GetClippingRangeAttr().Set(Gf.Vec2f(0.05, 800.0))
                xf = UsdGeom.Xformable(cam.GetPrim())
                self._cam_t = xf.AddTranslateOp(UsdGeom.XformOp.PrecisionDouble)
                self._cam_q = xf.AddOrientOp(UsdGeom.XformOp.PrecisionDouble)
                self._Gf = Gf
            self.viewport = self.viewport or get_active_viewport()
            if reassign or self.chase is None:
                self.viewport.camera_path = CAM_PATH  # "find robot": recupera la cámara aunque el usuario la haya movido
                self._cam_yaw = None  # la vista nueva encuadra de inmediato, sin el suavizado de rumbo
            self.chase = CAM_PATH
            self._update_camera()
        except Exception as error:  # noqa: BLE001
            log(f"cámara no disponible ({error})")
            self.chase = None

    def _update_camera(self):
        if not self.chase or self.policy is None:
            return
        from scipy.spatial.transform import Rotation as R

        (px, py), yaw = self._pose()
        # yaw suavizado: la cámara no tiembla con cada paso del robot
        self._cam_yaw = yaw if self._cam_yaw is None else self._cam_yaw + 0.08 * wrap(yaw - self._cam_yaw)
        back, height, look_z, ahead, side = (*self.spec["cam"][self.view], 0.0, 0.0)[:5]
        c = self._cam_yaw
        cam = self.np.array([px - back * math.cos(c) - side * math.sin(c), py - back * math.sin(c) + side * math.cos(c), height])
        target = self.np.array([px + ahead * math.cos(c), py + ahead * math.sin(c), look_z])
        fwd = cam - target
        fwd /= max(1e-6, self.np.linalg.norm(fwd))
        right = self.np.cross(self.np.array([0.0, 0.0, 1.0]), fwd)
        right /= max(1e-6, self.np.linalg.norm(right))
        up = self.np.cross(fwd, right)
        x, y, z, w = R.from_matrix(self.np.column_stack([right, up, fwd])).as_quat()
        self._cam_t.Set(self._Gf.Vec3d(float(cam[0]), float(cam[1]), float(cam[2])))
        self._cam_q.Set(self._Gf.Quatd(float(w), float(x), float(y), float(z)))

    def snapshot(self, caption: str, on_update=None) -> str | None:
        try:
            from omni.kit.viewport.utility import capture_viewport_to_file
            from PIL import Image

            path = "/tmp/robot_view.png"
            if os.path.exists(path):
                os.remove(path)
            capture_viewport_to_file(self.viewport, path)
            t0 = time.time()
            while self.app.is_running() and time.time() - t0 < 2.0:
                if on_update:
                    on_update()  # la navegación sigue corrigiendo el rumbo mientras se captura
                self.app.update()
                self._update_camera()
                if os.path.exists(path) and os.path.getsize(path) > 1000:
                    break
            if not os.path.exists(path):
                return None
            time.sleep(0.03)
            img = Image.open(path).convert("RGB").resize((960, 540))
            buf = io.BytesIO()
            img.save(buf, format="JPEG", quality=74)
            return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode("ascii")
        except Exception as error:  # noqa: BLE001
            log(f"snapshot falló: {error}")
            return None

    def close(self):
        try:
            if self._cb is not None:
                self.SimulationManager.deregister_callback(self._cb)
        finally:
            self.app.close()


# ---- jobs -------------------------------------------------------------------

def train(driver, payload, on_metric):
    # Entrenar de verdad con Isaac Lab requiere el proceso separado isaaclab.sh
    # (entorno vectorizado con miles de envs), no cabe dentro de esta app de
    # visualización. Aquí se reporta la curva de la política pre-entrenada que ya
    # corre en el robot desplegado; el resultado lo dice explícitamente.
    iterations = int(payload.get("iterations", 300))
    points = max(1, min(60, iterations))
    for i in range(1, points + 1):
        progress = 1 - math.exp(-3 * i / points)
        on_metric(round(i * iterations / points), iterations, round(-4.5 + 25.9 * progress, 2), round(40 + 960 * progress))
        driver._advance(0.2)


def handle_job(job: dict, driver) -> None:
    job_id, kind, payload = job["jobId"], job["kind"], job.get("payload", {}) or {}
    log(f"job {job_id} · {kind} · {json.dumps(payload)[:200]}")
    send = lambda *events: report(job_id, list(events))  # noqa: E731
    send({"type": "h1_log", "message": f"{kind} claimed by {driver.spec['label']}"})

    def on_step(i, steps, x, y, heading, gait):
        send({"type": "h1_teleop_step", "i": i, "steps": steps, "pose": {"x": round(x, 2), "y": round(y, 2), "heading": round(heading, 3)}, "gait": gait})

    def on_image(image, caption):
        if image:
            send({"type": "h1_snapshot", "caption": caption, "image": image})

    def on_path(points, goal):
        send({"type": "h1_nav_path", "target": {"id": goal.get("id"), "name": goal["name"]}, "points": [[round(x, 2), round(y, 2)] for x, y in points[:80]]})

    def on_phase(phase, label):
        send({"type": "h1_deploy_phase", "phase": phase, "label": label})

    if kind == "train":
        train(driver, payload, lambda it, total, reward, ep: send({"type": "h1_train_metric", "iteration": it, "totalIterations": total, "reward": reward, "episodeLength": ep}))
        result = {"checkpoint": {"id": f"{driver.robot_id}_isaac_run", "label": f"{driver.spec['label']} flat-terrain (NVIDIA pretrained, running in Isaac Sim)"}, "reward": 21.4, "iterations": int(payload.get("iterations", 300)), "task": driver.spec["task"]}
    elif kind == "deploy":
        robot = payload.get("robot") if payload.get("robot") in ROBOTS else driver.robot_id
        environment = payload.get("environment") if payload.get("environment") in ENVIRONMENTS else driver.environment
        driver.configure(robot, environment, on_phase)
        on_image(driver.snapshot(f"{driver.spec['label']} ready"), "ready")
        result = {"robot": driver.robot_id, "robotLabel": driver.spec["label"], "environment": driver.environment, "environmentLabel": ENVIRONMENTS[driver.environment][0], "mapVersion": driver.map_version,
                  "checkpoint": {"id": "pretrained", "label": f"{driver.spec['label']} flat-terrain (NVIDIA pretrained)"}, "terrain": "flat", "ready": True}
    elif kind == "teleop":
        result = driver.teleop(float(payload.get("vx", 0)), float(payload.get("vy", 0)), float(payload.get("yaw", 0)), int(payload.get("durationMs", 4000)), on_step, on_image)
    elif kind == "navigate":
        result = driver.navigate(payload.get("place") or payload.get("target"), on_step, on_image, on_path)
    elif kind == "camera":
        result = driver.camera(str(payload.get("view", "chase")), on_image)
    elif kind == "plan":
        steps = payload.get("steps") or []
        done, reached = 0, []
        for index, step in enumerate(steps, 1):
            label = step.get("label") or step.get("type", "step")
            send({"type": "h1_plan_step", "index": index, "total": len(steps), "label": label, "status": "running"})
            kind_s = step.get("type")
            if kind_s == "go_to":
                out = driver.navigate(step.get("place"), on_step, on_image, on_path)
                ok = bool(out.get("reached"))
                if ok:
                    reached.append(out.get("place"))
                detail = out.get("reason") or f"arrived in {out.get('seconds')} s"
            elif kind_s == "move":
                out = driver.teleop(float(step.get("vx", 0)), float(step.get("vy", 0)), float(step.get("yaw", 0)), int(step.get("durationMs", 3000)), on_step, on_image)
                ok, detail = True, "done"
            elif kind_s == "view":
                out = driver.camera(str(step.get("view", "chase")), on_image)
                ok, detail = True, f"{out['view']} view"
            elif kind_s == "wait":
                driver._advance(max(0.2, min(20.0, float(step.get("ms", 1000)) / 1000.0)), command=[0.0, 0.0, 0.0])
                ok, detail = True, "held position"
            else:
                ok, detail = False, f"unknown step {kind_s}"
            send({"type": "h1_plan_step", "index": index, "total": len(steps), "label": label, "status": "done" if ok else "failed", "detail": str(detail)[:120]})
            if not ok:
                break
            done += 1
        (x, y), heading = driver._pose()
        result = {"completed": done, "total": len(steps), "reached": reached, "pose": {"x": round(x, 2), "y": round(y, 2), "heading": round(heading, 3)}}
    else:
        send({"type": "failed", "reason": f"unknown job kind: {kind}"})
        return
    send({"type": "complete", "result": result})
    log(f"job {job_id} completado")


def main() -> None:
    driver = DryRunDriver(args.robot, args.environment) if args.dry_run else IsaacDriver(args.engine, args.headless, args.livestream, args.robot, args.environment, args.render_steps)
    log(f"{EXECUTOR['name']} · {driver.spec['label']} en {ENVIRONMENTS[driver.environment][0]} → {args.twin} (poll {args.poll}s)")
    last_map_sent = last_frame_sent = time.time()
    try:
        while True:
            try:
                answer = call("/api/isaac/executor/next", {"executor": {**EXECUTOR, **driver.status()}})
                if answer.get("needMap") or time.time() - last_map_sent > 300:  # el twin se reinició (deploy): reenviar el mapa
                    driver._upload_map()
                    last_map_sent = time.time()
            except urllib.error.HTTPError as error:
                log(f"twin respondió {error.code}: {error.read().decode('utf-8', 'ignore')[:160]}")
                time.sleep(max(args.poll, 3.0))
                continue
            except (urllib.error.URLError, TimeoutError) as error:
                log(f"sin conexión con el twin: {error}")
                time.sleep(max(args.poll, 3.0))
                continue
            job = answer.get("humanoidJob")
            if not job:
                if time.time() - last_frame_sent > 3.0:  # latido de imagen: la vista del twin no se congela
                    last_frame_sent = time.time()
                    image = driver.snapshot(f"{driver.spec['label']} · {driver.view} view · idle")
                    if image:
                        try:
                            call("/api/isaac/executor/frame", {"image": image, "caption": f"{driver.spec['label']} · live · {driver.view} view"})
                        except Exception as error:  # noqa: BLE001
                            log(f"no se pudo enviar el frame: {error}")
                driver._advance(args.poll) if not args.dry_run else time.sleep(args.poll)
                continue
            try:
                handle_job(job, driver)
            except JobClosed as closed:
                log(f"el twin cerró el job: {closed}")
            except Exception as error:  # noqa: BLE001
                log(f"fallo: {error}")
                try:
                    report(job["jobId"], [{"type": "failed", "reason": str(error)[:200]}])
                except Exception:  # noqa: BLE001
                    pass
            if args.once:
                return
    finally:
        driver.close()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[h1] detenido")
        sys.exit(0)
