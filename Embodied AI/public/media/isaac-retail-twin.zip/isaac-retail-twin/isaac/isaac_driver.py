# Driver físico del ejecutor: mueve el AMR (Nova Carter) en Isaac Sim entre los
# nodos que manda el twin y toma fotos con la cámara del robot.
#
# Solo se importa cuando el ejecutor corre SIN --dry-run. Requiere Isaac Sim 5.x
# (./python.sh). La escena base viene de scenario/warehouse.json (entorno de
# Isaac + racks); los nodos del twin se dibujan como marcadores etiquetados.

from __future__ import annotations

import base64
import io
import math
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class IsaacDriver:
    def __init__(self, scenario_path: str | None, headless: bool = False, speed: float = 0.8, twin_offset=(-10.0, 5.0, 0.0), livestream: bool = False):
        from isaacsim import SimulationApp

        # En Brev / contenedores no hay ventana: headless + livestream y se ve en la pestaña /viewer.
        self.app = SimulationApp({"headless": headless or livestream, "width": 1920, "height": 1080, "window_width": 1920, "window_height": 1080})
        if livestream:
            import omni.kit.app

            manager, enabled = omni.kit.app.get_app().get_extension_manager(), None
            for name in ("omni.kit.livestream.app", "omni.kit.livestream.webrtc"):  # 6.x, luego 5.x
                try:
                    manager.set_extension_enabled_immediate(name, True)
                    if manager.is_extension_enabled(name):
                        enabled = name
                        break
                except Exception:  # noqa: BLE001
                    continue
            self.app.set_setting("/app/window/drawMouse", True)
            print(f"[isaac] livestream: {enabled or 'NO disponible (revisa runheadless.sh del Launchable)'}")
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        import numpy as np
        from isaacsim.core.api import World
        from isaacsim.core.api.objects import VisualCuboid
        from isaacsim.robot.wheeled_robots.controllers.differential_controller import DifferentialController

        from store_scene import SCENARIO, attach_shelf_camera, build_store, heading_to, label, load_scenario, spawn_amr

        self.np, self.VisualCuboid, self.label, self.heading_to = np, VisualCuboid, label, heading_to
        self.speed, self.offset = speed, np.array(twin_offset)
        self.scenario = load_scenario(Path(scenario_path) if scenario_path else ROOT / "scenario" / "warehouse.json")
        self.world = World(stage_units_in_meters=1.0)
        build_store(self.world, self.scenario)
        robot_cfg = next(r for r in self.scenario["robots"] if r["kind"] == "amr")
        self.robot_path, self.robot = spawn_amr(self.world, robot_cfg)
        if self.robot is None:
            raise RuntimeError("No se pudo cargar el AMR como WheeledRobot; revisa asset_candidates en el scenario")
        self.camera = attach_shelf_camera(self.robot_path, {**robot_cfg, "camera_yaw_deg": 0, "camera_offset": [0.35, 0.0, 1.1]})
        self.world.reset()
        self.camera.initialize()
        self.controller = DifferentialController(name="twin_diff", wheel_radius=robot_cfg["wheel_radius"], wheel_base=robot_cfg["wheel_base"])
        self.markers, self.nodes, self.pos = {}, {}, None
        self._add_lights()
        # El USD del entorno/robot puede traer su propio origen (a veces lejos de 0,0 en
        # assets escaneados). En vez de confiar en el "dock" del JSON, anclamos el mapa del
        # twin a donde el robot REALMENTE apareció tras spawn+reset.
        spawn_xy, _ = self._pose()
        dock_xy = (float(robot_cfg["dock"][0]), float(robot_cfg["dock"][1]))
        self.offset = self.offset + self.np.array([spawn_xy[0] - dock_xy[0], spawn_xy[1] - dock_xy[1], 0.0])
        print(f"[isaac] anclaje: robot apareció en {tuple(round(v,2) for v in spawn_xy)} (esperado dock {dock_xy}) · offset ajustado a {tuple(round(v,2) for v in self.offset[:2])}")
        self._setup_chase_cam()
        print(f"[isaac] escena lista · {self.scenario['name']} · AMR en {self.robot_path}")

    def _add_lights(self) -> None:
        """Luz propia SOLO si el entorno no trae luces; con intensidad moderada para no sobreexponer."""
        try:
            import omni.usd
            from isaacsim.core.utils.prims import create_prim
            from pxr import UsdLux

            stage = omni.usd.get_context().get_stage()
            lights = [p.GetPath().pathString for p in stage.Traverse() if p.IsA(UsdLux.LightAPI) or p.GetTypeName().endswith("Light")]
            env_prims = sum(1 for p in stage.Traverse() if p.GetPath().pathString.startswith("/World/Env"))
            print(f"[isaac] entorno: {env_prims} prims bajo /World/Env · luces existentes: {len(lights)} {lights[:4]}")
            if lights:
                return
            dome = create_prim("/World/TwinLights/Dome", "DomeLight")
            UsdLux.DomeLight(dome).GetIntensityAttr().Set(300.0)
            sun = create_prim("/World/TwinLights/Sun", "DistantLight")
            UsdLux.DistantLight(sun).GetIntensityAttr().Set(600.0)
            UsdLux.DistantLight(sun).GetAngleAttr().Set(1.0)
            print("[isaac] luces propias añadidas (dome 300 + distant 600)")
        except Exception as error:  # noqa: BLE001
            print(f"[isaac] no pude revisar/añadir luces: {error}")

    # ---- cámara de seguimiento ----------------------------------------------
    def _setup_chase_cam(self) -> None:
        """Cámara que sigue al robot desde atrás y arriba; se vuelve la cámara del viewport
        (lo que muestra el stream) y la fuente de las fotos para el twin."""
        self.chase = None
        try:
            from omni.kit.viewport.utility import get_active_viewport
            from pxr import Gf, UsdGeom
            from isaacsim.core.utils.prims import create_prim, get_prim_at_path

            path = "/World/ChaseCam"
            create_prim(path, "Camera")
            usd_cam = UsdGeom.Camera(get_prim_at_path(path))
            usd_cam.GetFocalLengthAttr().Set(16.0)
            usd_cam.GetClippingRangeAttr().Set(Gf.Vec2f(0.05, 600.0))
            xf = UsdGeom.Xformable(get_prim_at_path(path))
            xf.ClearXformOpOrder()
            # Isaac 6 crea la cámara con ops en doble precisión: pedir la misma precisión.
            self._cam_t = xf.AddTranslateOp(UsdGeom.XformOp.PrecisionDouble)
            self._cam_q = xf.AddOrientOp(UsdGeom.XformOp.PrecisionDouble)
            self._Gf = Gf
            self.viewport = get_active_viewport()
            self.viewport.camera_path = path
            self.chase = path
            self._snap_counter = 0
            self._update_chase_cam()
            print(f"[isaac] chase cam activa en el viewport (camera_path={self.viewport.camera_path}, viewport={getattr(self.viewport, 'resolution', '?')})")
        except Exception as error:  # noqa: BLE001
            print(f"[isaac] chase cam no disponible ({error}); se usará la cámara del robot")

    def _update_chase_cam(self) -> None:
        if not self.chase:
            return
        from scipy.spatial.transform import Rotation as R

        (px, py), yaw = self._pose()
        cam = self.np.array([px - 4.5 * math.cos(yaw), py - 4.5 * math.sin(yaw), 3.2])
        target = self.np.array([px, py, 0.6])
        back = cam - target; back /= self.np.linalg.norm(back)
        right = self.np.cross(self.np.array([0.0, 0.0, 1.0]), back); right /= self.np.linalg.norm(right)
        up = self.np.cross(back, right)
        x, y, z, w = R.from_matrix(self.np.column_stack([right, up, back])).as_quat()
        self._cam_t.Set(self._Gf.Vec3d(float(cam[0]), float(cam[1]), float(cam[2])))
        self._cam_q.Set(self._Gf.Quatd(float(w), float(x), float(y), float(z)))

    # ---- misión -----------------------------------------------------------
    def reset(self, nodes: dict) -> None:
        """Dibuja los nodos del twin como marcadores y coloca al robot en el primero."""
        self.nodes = {nid: self._world_xy(n["meters"]) for nid, n in nodes.items()}
        for nid, n in nodes.items():
            if nid in self.markers:
                continue
            x, y = self.nodes[nid]
            path = f"/World/TwinNodes/{nid.replace('-', '_')}"
            self.markers[nid] = self.world.scene.add(self.VisualCuboid(prim_path=path, name=f"twin_node_{nid.replace('-', '_')}", position=self.np.array([x, y, 0.4]), scale=self.np.array([0.6, 0.6, 0.8]), color=self._color(n.get("kind"))))
            self.label(path, f"node_{nid}")
        self.pos = None

    def _world_xy(self, meters):
        return (meters[0] + float(self.offset[0]), meters[1] + float(self.offset[1]))

    def _color(self, kind):
        palette = {"agent": [0.10, 0.45, 0.85], "bdc": [0.55, 0.30, 0.80], "data": [0.20, 0.65, 0.55], "audit": [0.85, 0.35, 0.35], "source": [0.85, 0.60, 0.15]}
        return self.np.array(palette.get(kind, [0.6, 0.6, 0.6]))

    def _pose(self):
        pos, quat = self.robot.get_world_pose()
        w, x, y, z = quat
        return (float(pos[0]), float(pos[1])), math.atan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))

    def travel(self, from_id: str, to_id: str, on_frame=None) -> float:
        """Navegación punto a punto con controlador diferencial; devuelve segundos reales.
        on_frame(image, caption) recibe una foto de la cámara del robot cada segundo.

        Salvaguardas: (a) freno ABSOLUTO — el robot nunca puede alejarse más de
        ABSOLUTE_MAX_M de donde arrancó ESTE viaje, sin importar el objetivo; corta ahí
        mismo. (b) si la velocidad medida entre frames es fisicamente imposible para este
        robot, algo lo está empujando (colisión/física inestable) y se detiene también.
        Antes de mover, siempre se manda [0,0] primero para no arrastrar velocidad previa."""
        ABSOLUTE_MAX_M = 60.0
        target = self.nodes[to_id]
        start_pose, _ = self._pose()
        self.robot.apply_wheel_actions(self.controller.forward(command=[0.0, 0.0]))
        for _ in range(3):
            self.world.step(render=True)
        max_dist = min(ABSOLUTE_MAX_M, max(3.0, 2.0 * math.hypot(target[0] - start_pose[0], target[1] - start_pose[1])))
        t0, deadline = time.time(), time.time() + max(15.0, 4.0 * math.hypot(*(self.nodes[to_id][i] - self.nodes.get(from_id, self.nodes[to_id])[i] for i in range(2))) / self.speed)
        last_frame, last_pose, last_t, runaway = 0.0, start_pose, time.time(), False
        while self.app.is_running() and time.time() < deadline:
            self.world.step(render=True)
            self._update_chase_cam()
            if on_frame and time.time() - last_frame >= 1.0:
                last_frame = time.time()
                on_frame(self.camera_snapshot(f"{from_id} → {to_id}"), f"{from_id} → {to_id}")
            (px, py), yaw = self._pose()
            now, dt = time.time(), max(1e-3, time.time() - last_t)
            measured_speed = math.hypot(px - last_pose[0], py - last_pose[1]) / dt
            if measured_speed > self.speed * 6:  # el robot no puede moverse 6x más rápido de lo comandado sin ser un empujón físico
                print(f"[isaac] travel abortado: velocidad medida {measured_speed:.1f} m/s imposible (comandada {self.speed} m/s) · posición {(round(px,1), round(py,1))}")
                runaway = True
                break
            if math.hypot(px - start_pose[0], py - start_pose[1]) > max_dist:
                print(f"[isaac] travel abortado: el robot se alejó más de {max_dist:.1f} m de {tuple(round(v,1) for v in start_pose)} · posición actual {(round(px,1), round(py,1))}")
                runaway = True
                break
            last_pose, last_t = (px, py), now
            dist = math.hypot(target[0] - px, target[1] - py)
            if dist < 0.35:
                break
            err = (self.heading_to((px, py), target) - yaw + math.pi) % (2 * math.pi) - math.pi
            lin = self.speed if abs(err) < 0.35 else 0.0
            self.robot.apply_wheel_actions(self.controller.forward(command=[lin, max(-1.2, min(1.2, 2.0 * err))]))
        self.robot.apply_wheel_actions(self.controller.forward(command=[0.0, 0.0]))
        for _ in range(3):
            self.world.step(render=True)
        if runaway:
            print("[isaac] recuperando: reposicionando el robot en el punto de partida del viaje")
            self.robot.set_world_pose(position=self.np.array([start_pose[0], start_pose[1], 0.15]))
            for _ in range(3):
                self.world.step(render=True)
            self.pos = from_id
        else:
            self.pos = to_id
        return time.time() - t0

    def act(self, step: dict) -> float:
        """El robot 'trabaja' en el nodo: se queda quieto (ruedas a 0) mientras dura el paso."""
        dwell, t0 = max(1.0, float(step.get("duration", 1)) * 1.5), time.time()
        self.robot.apply_wheel_actions(self.controller.forward(command=[0.0, 0.0]))
        while self.app.is_running() and time.time() - t0 < dwell:
            self.world.step(render=True)
            self._update_chase_cam()
        self.robot.apply_wheel_actions(self.controller.forward(command=[0.0, 0.0]))
        return time.time() - t0

    def _encode(self, rgb, source: str) -> str | None:
        from PIL import Image

        arr = self.np.asarray(rgb)
        if arr.ndim != 3 or arr.shape[0] < 8:
            return None
        mean = float(arr[:, :, :3].mean())
        self._snap_log = getattr(self, "_snap_log", 0) + 1
        if self._snap_log % 5 == 1:
            (px, py), yaw = self._pose()
            print(f"[isaac] foto #{self._snap_log}: fuente={source} · {arr.shape[1]}x{arr.shape[0]} · brillo medio={mean:.1f} · robot=({px:.1f},{py:.1f}) yaw={math.degrees(yaw):.0f}°")
        if mean < 2.0:  # imagen negra: no sirve, que pruebe la siguiente fuente
            return None
        img = Image.fromarray(arr[:, :, :3].astype("uint8")).resize((640, 360))
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=72)
        return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode("ascii")

    def _annotator_snapshot(self) -> str | None:
        """Render product + anotador RGB sobre la chase cam (la vía estándar de Replicator)."""
        try:
            import omni.replicator.core as rep

            if not hasattr(self, "_ann"):
                self._rp = rep.create.render_product(self.chase, (960, 540))
                self._ann = rep.AnnotatorRegistry.get_annotator("rgb")
                self._ann.attach([self._rp])
                for _ in range(6):
                    self.world.step(render=True)
            data = self._ann.get_data()
            if isinstance(data, dict):
                data = data.get("data", data)
            arr = data.numpy() if hasattr(data, "numpy") else self.np.asarray(data)
            return self._encode(arr, "chase-annotator")
        except Exception as error:  # noqa: BLE001
            print(f"[isaac] anotador de la chase cam falló: {error}")
            return None

    def camera_snapshot(self, caption: str) -> str | None:
        for _ in range(2):
            self.world.step(render=True)
        if self.chase:
            image = self._annotator_snapshot() or self._viewport_snapshot()
            if image:
                return image
        try:
            return self._encode(self.camera.get_rgba(), "robot-cam")
        except Exception as error:  # noqa: BLE001
            print(f"[isaac] sin foto: {error}")
            return None

    def _viewport_snapshot(self) -> str | None:
        """Captura lo que ve el viewport (la chase cam) a un PNG temporal y lo devuelve como JPEG base64."""
        try:
            import os
            from omni.kit.viewport.utility import capture_viewport_to_file
            from PIL import Image

            self._snap_counter += 1
            path = f"/tmp/twin_chase_{self._snap_counter % 4}.png"
            if os.path.exists(path):
                os.remove(path)
            capture_viewport_to_file(self.viewport, path)
            t0 = time.time()
            while self.app.is_running() and time.time() - t0 < 2.0:
                self.world.step(render=True)
                if os.path.exists(path) and os.path.getsize(path) > 1000:
                    break
            if not os.path.exists(path):
                return None
            time.sleep(0.05)
            return self._encode(self.np.asarray(Image.open(path).convert("RGB")), "viewport")
        except Exception as error:  # noqa: BLE001
            print(f"[isaac] captura de viewport falló: {error}")
            return None

    def idle(self, seconds: float) -> None:
        """Mantiene viva la simulación mientras el ejecutor espera misión."""
        t0 = time.time()
        while self.app.is_running() and time.time() - t0 < seconds:
            self.world.step(render=True)
            self._update_chase_cam()

    def close(self) -> None:
        self.app.close()
