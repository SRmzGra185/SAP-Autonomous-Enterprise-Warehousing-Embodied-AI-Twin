# Retail Store Twin · Paso 1: construir y ver la tienda en Isaac Sim
#
# Ejecutar dentro de la instalación de Isaac Sim (Brev o contenedor):
#   ./python.sh /workspace/isaac-retail-twin/isaac/build_store.py
#   ./python.sh /workspace/isaac-retail-twin/isaac/build_store.py --headless --save /workspace/store_twin.usd
#
# Construye piso, paredes, 5 góndolas con productos etiquetados semánticamente,
# el AMR escáner en su dock y deja la simulación corriendo para inspeccionarla.

import argparse
import sys
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--headless", action="store_true")
parser.add_argument("--scenario", default=None, help="Ruta a store.json (default: scenario/store.json)")
parser.add_argument("--save", default=None, help="Guardar la escena como USD y salir")
args, _ = parser.parse_known_args()

from isaacsim import SimulationApp

simulation_app = SimulationApp({"headless": args.headless})

sys.path.insert(0, str(Path(__file__).resolve().parent))
import omni.usd  # noqa: E402
from isaacsim.core.api import World  # noqa: E402

from store_scene import SCENARIO, attach_shelf_camera, build_store, load_scenario, spawn_amr  # noqa: E402

scenario = load_scenario(Path(args.scenario) if args.scenario else SCENARIO)
world = World(stage_units_in_meters=1.0)
ground_truth = build_store(world, scenario)

scanner = next(r for r in scenario["robots"] if r["role"] == "shelf-scanner")
robot_path, wheeled = spawn_amr(world, scanner)
camera = attach_shelf_camera(robot_path, scanner) if wheeled is not None else None

world.reset()
if camera is not None:
    camera.initialize()

if args.save:
    omni.usd.get_context().save_as_stage(args.save)
    print(f"[build_store] Escena guardada en {args.save}")
    simulation_app.close()
    sys.exit(0)

print("[build_store] Tienda lista. Cierra la ventana o Ctrl+C para salir.")
while simulation_app.is_running():
    world.step(render=True)

simulation_app.close()
