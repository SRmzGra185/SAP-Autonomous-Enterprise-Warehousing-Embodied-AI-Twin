#!/usr/bin/env bash
# Preparar la instancia de Brev (Isaac Launchable) para el Retail Store Twin.
# Ejecutar en la terminal de VS Code de la instancia, una sola vez.
set -euo pipefail

REPO_URL="${1:-}"                      # p. ej. https://github.com/<usuario>/isaac-retail-twin
WORK=/workspace
cd "$WORK"

if [ -n "$REPO_URL" ] && [ ! -d isaac-retail-twin ]; then git clone "$REPO_URL"; fi
cd isaac-retail-twin

# Localizar el python.sh de Isaac Sim (varía entre el Launchable y el contenedor)
for cand in /isaac-sim/python.sh "$HOME/isaacsim/python.sh" /workspace/isaacsim/python.sh; do
  if [ -x "$cand" ]; then ISAAC_PY="$cand"; break; fi
done
: "${ISAAC_PY:?No encontré python.sh de Isaac Sim; expórtalo como ISAAC_PY}"
echo "Isaac python: $ISAAC_PY"
"$ISAAC_PY" -c "import isaacsim, sys; print('isaacsim OK', sys.version.split()[0])"

# 1) Ver la tienda (abre la ventana de Isaac Sim en el streaming del navegador)
echo "Paso 1:  $ISAAC_PY isaac/build_store.py"
# 2) Correr la misión de escaneo y guardar evidencia
echo "Paso 2:  $ISAAC_PY isaac/scan_mission.py --mission scan-A1-A5                                            # tienda"
echo "         $ISAAC_PY isaac/scan_mission.py --scenario scenario/warehouse.json --mission scan-P1-P4        # almacén"
# 3) Con el mock SAP corriendo (python3 sap/mock_server.py &), enviar resultados
echo "Paso 3:  $ISAAC_PY isaac/scan_mission.py --mission scan-A1-A5 --headless --post"
